<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['kolor'])){
  if($_SESSION['kolor'] != 'MIX'){
    header('Location: login.php');
    exit();
  }
}

if(!isset($_SESSION['kolor'])){
  require_once "polacz.php";
    try{
    
    $lacze = new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
    
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
      
    }else{
      $id = $_SESSION['id'];
      
      $wstawienie = $lacze->query("INSERT INTO testy (id_uzytkownika) VALUES ('$id')");
        if($wstawienie){
          $_SESSION['czy_kwestionariusz'] = true;
          $_SESSION['kolor'] = 'MIX';
          $_SESSION['zapisano_kwestionariusz'] = true;
          }else{
            throw new Exception($lacze->error);
        }
        $lacze->close();
    }
  }catch(Exception $ex){
    echo '<span class="komunikat2"> Błąd serwera, proszę spróbować później! </span>';
      header('Location: kwestionariusz.php');
  }
}
?>
<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Twój typ osobowości | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_typ.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego</div>
    </header>
<!--***********************NAWIGACJA**********************		-->
 <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'MIX'){
          echo '<a id="aktywna" href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
       <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
   
  <?php
      if(isset( $_SESSION['zapisano_kwestionariusz']) && ( $_SESSION['zapisano_kwestionariusz'] == true)){
        echo '<div class="naglowek" style="color:green">Twój wynik został zapisany!</div>';
        unset( $_SESSION['zapisano_kwestionariusz']);
      }
  ?>
   <div class="naglowek"> Twój typ osobowości to typ mieszany</div><br> 
      Czasem zdarza się, iż wyniki jednorazowego wypełnienienia kwestionariusza osobowościowego nie wystarczają, aby jednoznacznie zdefiniować typ osobowości. Jest wiele przyczyn, między innymi posiadanie bardzo złożonej mieszanki co najmniej dwóch kolorów osobowości, często bardzo odmiennych. <br> <br> 
      
      Uzyskanie jednoznacznych wyników wymaga w tej sytuacji  konsultacji ze specjalistą i ponownego wypełnienia kwestionariusza. Doradca zawodowy podczas konsultacji udzieli wskazówek dotyczących ponownego wypełnienia kwestionariusza oraz szczegółowych odpowiedzi na wszelkie pytania.<br><br> <br> <br> 
    
      
      <div class="zrodlo">
        Opracowano na podstawie: Taylor Hartman, "Kod kolorów. Typy osobowości zaszyfrowane w kolorach.", przekł. Lidia Rafa, Warszawa: Amber 1999.
      </div>
    </div>      <br><br><br>
<!--***********************SKRYPTY**********************		-->  
    <script>
        $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
    </script>
    <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
    </body> 
</html>