<?php
session_start();

if((isset($_SESSION['zalogowanie'])) && ($_SESSION['zalogowanie']==true)){
  header('Location: login.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title>Strona główna | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Centrum Doradztwa Zawodowego. Z nami dowiesz sie, jaki zawód jest Ci pisany!">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_indeks.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
      <script src='https://www.google.com/recaptcha/api.js'></script>
      
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
<?php
        if(isset($_SESSION['blad'])){
        echo  $_SESSION['blad'];
        }
?>
        <a href="rejestracja.php" class="zaloguj"> Zarejestruj się </a>&nbsp;|&nbsp;
        <button class="zaloguj" id="zaloguj">Zaloguj&nbsp;</button>
      </div>
<!--***********************ZALOGUJ**********************		-->   
      <div class="loguj" id="loguj"> 
      <form class="formularz_logowania" action="logowanie.php" method="post"> 
    
        <div id="naglowek"> Logowanie do serwisu Centrum Doradztwa Zawodowego</div>
        <div id="zamknij" class="zamknij" title="Zamknij okno">&times;</div> 
        <div id='polecenie' > Podaj adres e-mail oraz hasło </div>
        <div id='formularz'> 
      
          <label>E-mail:</label>
          <input type="text" placeholder="np. jankowalski@gmail.com" name="email" required/>
          <br>
          <label>Hasło:</label>
          <input type="password" placeholder="Haslo" name="haslo" required/>
          <br>
            <div id="ikony_pod">
              <input type="submit" value="Zaloguj">
              <br>
            </div>
          <span id='do_rejestracji'> Nie masz konta? Zarejestruj się! </span>
        </div>
      </form>
      </div> 
   
     
<!--***********************Tytul**********************		-->
      <header>
      <div id="nazwa"> Centrum Doradztwa Zawodowego</div>
    </header>
<!--***********************NAWIGACJA**********************		-->
      <nav>
    <div id="nawigacja" class="nav">
      <a href="#start">Start</a>
      <a href="#d_z">Doradztwo zawodowe</a>
      <a href="#zespol">Kim jest doradca?</a>
      <a href="#oferta">Oferta Centrum</a>
      <a href="#zapisy">Zapisy online</a>
      <a href="#kontakt">Kontakt</a>
      <a href="javascript:void(0);" class="icon" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
<!--***********************START**********************		-->
      <div class="start" id="start">
       
        <div class="naglowek">
            Witaj na stronie Centrum Doradztwa Zawodowego!<div class="wyroznij2">„Obuwie i zawód trzeba mieć na miarę” - Wilam Horzyca</div>
            </div>
        <br>
        Centrum Doradztwa Zawodowego oferuje konsultacje indywidualne podczas których profesjonalny doradca zawodowy pomoże określić Twoje predyspozycje i preferencje zawodowe oraz udzieli informacji niezbędnych w zaplanowaniu ścieżki edukacyjno – zawodowej.
        <br>
        <br>
        Zapisy na spotkanie z doradcami naszego centrum odbywają się WYŁĄCZNIE online. Więcej informacji w zakładce<a href="#zapisy"> Zapisy online</a>.
        </div>
<!--***********************DORADZTWO**********************		-->
      <div class="d_z" id="d_z">
         
        <div class="naglowek">Czym jest doradztwo zawodowe?</div>
         <br>
         Doradztwo zawodowe rozumiane jest jako działalność polegająca na udzielaniu indywidualnych porad w zakresie wyboru zawodu, przygotowania zawodowego, doboru odpowiedniego miejsca i stanowiska pracy, doskonalenia lub zmiany kwalifikacji. Podstawowym celem doradztwa zawodowego jest pomoc w podejmowaniu decyzji dotyczących edukacji i życia zawodowego na różnych etapach rozwoju człowieka. Pierwszy kontakt z tą formą aktywizacji zawodowej zwykle odbywa się w okresie szkolnym i dotyczy osób młodocianych na etapie wyboru kolejnej szkoły. W przypadku dorosłych doradztwo ma formę konsultacji w zakresie reorientacji zawodowej oraz prognoz na rynku pracy. 
         <br>
         <br>
         Poradnictwo zawodowe jest procesem długotrwałym. W założeniu powinien on zaczynać się we wczesnym dzieciństwie i trwać przez cały okres życia. Z uwagi na złożoność jego przebiegu wymaga on odpowiedniej ilości informacji oraz porady z zewnątrz. 
        </div>
<!--***********************NASZ ZESPOL**********************		-->
     <div class="zespol" id="zespol">
       
      <div class="naglowek">Kim jest doradca zawodowy?</div>
      <br>
      Jest specjalistą, który wesprze Cię w planowaniu kariery edukacyjno-zawodowej.
      <br>
      <br>
       Zadaniem doradcy zawodowego jest towarzyszenie podopiecznemu podczas kluczowych momentów życia zawodowego, dostarczanie istotnych informacji o sytuacji na rynku pracy jak i pomoc w lepszym zrozumienia samego siebie w odniesieniu do środowiska pracy.
      <br>
      <br>
      Doradca zawodowy pomoże Ci w określeniu Twojego potencjału – czyli m.in. zainteresowań, umiejętności, predyspozycji czy osobowości zawodowej i na ich podstawie przedstawi Ci potencjalne zawody, w których mógłbyś najpełniej rozwijać swoje możliwości.
      <br>
      <br> 
      Doradca – jak nazwa wskazuje – doradzi, wskaże, wyjaśni czy poinformuje – ale ostateczna decyzja o wyborze szkoły czy zawodu należeć będzie do Ciebie.
      </div>
<!--***********************OFERTA**********************		-->
  <div class="oferta" id="oferta">
    <div class="naglowek"> Centrum oferuje: </div>
    <br>
    <div class="wyroznij">Rozmowa diagnostyczna z doradcą zawodowym – 220 zł, 2 godziny zegarowe </div>
    Pierwsza rozmowa to rozmowa diagnostyczna, ale bardzo często jest to też rozmowa ostatnia. Zwykle już na pierwszym spotkaniu jesteśmy w stanie rozwiązać Twój problem: wyniki wypełnionego przez Ciebie kwestionariusza zdradzają Twoje preferencje zawodowe i zawody dedykowane dla Ciebie. Jeśli jednak stwierdzisz, że zachodzi taka potrzeba, zapraszamy Cię na kolejne spotkania indywidualne.
    <br>
    <br>
    <div class="wyroznij">Spotkanie indywidualne z doradcą zawodowym - 200 zł, 2 godziny zegarowe</div>
    Jeśli stwierdzimy, iż spotkanie dignostyczne to za mało, zapraszamy Cię na spotkanie indywidualne o tematyce dopasowanej do Twoich potrzeb.
    <br><br>
    Możliwe tematy takich spotkań to:<ul>
      <li>Badanie predyspozycji zawodowych</li>
      <li>Planowanie rozwoju zawodowego</li>
      <li>Ukazanie możliwości dostępnych na rynku pracy</li>
      <li>Tworzenie wizerunku zawodowego</li>
      <li>Zmiana pracy lub ścieżki kariery</li>
      <li>Rozwiązywanie problemów w pracy</li>
      <li>Wypalenie zawodowe</li>
    </ul>
    <br>
    <div class="wyroznij">Szkolenie indywidualne - 200 zł, 2 godziny zegarowe</div>
    Jeśli stwierdzimy, iż spotkanie dignostyczne to za mało i zaistnieje taka chęć lub potrzeba, zapraszamy Cię także na szkolenia indywidualnie. Służą one wyrabianiu nowych nawyków oraz ich utrwalaniu.
    <br>
    <br>
    Możliwe tematy szkoleń to:
    <ul>
      <li>Przygotowanie do rozmowy kwalifikacyjnej.</li>
      <li>Asertywność w pracy i rozwiazywanie konfliktów.</li>
      <li>Efektywna komunikacja.</li>
      <li>Lepsza organizacja pracy i skuteczna realizacja celów.</li>
    </ul>
        </div>
<!--***********************ZAPISY**********************		--> 
      <div class="zapisy" id="zapisy">
        <div class="naglowek">Jak umówić się na spotkanie?</div>
        <br>
        Zapisy na spotkania z doradcami odbywają się wyłącznie online, za pomocą konta osobistego w serwisie Centrum Doradztwa Zawodowego. <a href="powitanie.php"> ->ZALOGUJ SIĘ<- </a><a href="rejestracja.php"> ->ZAREJESTRUJ SIĘ<- </a>
        <br><br>
        Użytkownicy nieletni w procesie zakładania konta proszeni są dodatkowo o podanie adresu email, użytego w procesie rejestracji przez ich opiekuna prawnego. Brak podania adresu email opiekuna prawnego lub brak zgody posiadacza podanego adresu email na wykorzystanie jego adresu do tego celu skutkuje niemożnościa rejestracji w serwisie.
        <br><br>
        Umawiając się na spotkanie wybieramy jeden z wyznaczonych wcześniej przez doradców terminów dostępnych w systemie. Wyznaczone terminy obejmują zwykle okres do dwóch miesięcy. Jednorazowo można dokonać rezerwacji jednego terminu. 
        <br><br>
        Przed dokonaniem pierwszej rezerwacji użytkownik proszony jest o wypełnienie kwestionariusza osobowościowego. Na postawie zapisanych wyników kwestionariusza doradca będzie w stanie odpowiednio przygotować się do rozmowy diagnostycznej.
        <br><br>
        Na opłacenie zarezerwowanego terminu przeznaczono <b>3 dni</b>. Jeśli pomimo dokonania rezerwacji w systemie zostanie ona nieopłacona w terminie 3 dni, system automatycznie usunie rezerwację ORAZ konto użytkownika, który tej rezerwacji dokonał. <br><b>BARDZO PROSIMY WIĘC O TERMINOWE DOKONYWANIE WPŁAT.</b>
        <br><br>
        UWAGA! W razie usunięcia przez system konta użytkonika dorosłego będącego opiekunem prawnym małoletniego, wszystkie konta powązanych z nim małoletnich również zostaną automatycznie usunięte.
         
      </div>    
<!--***********************KONTAKT**********************		-->
      <div class="kontakt" id="kontakt">
         <div class="naglowek">Nasze dane kontaktowe</div>
  
    <br><span class="wyroznij"> Centrum Doradzwa Zawodowego Kraków, ul. ************* ****** </span> 
    <br> tel: 735 313 222
    <br> email: ******
    <br>
    <br><span class="wyroznij">Godziny otwarcia: </span> 
    <br>Centrum otwarte jest od poniedziałku do soboty w godzinach od 9.00 do 20.00.
    <br>
    <br><span class="wyroznij">Informacje o opłatach: </span>
    <br> Opłaty prosimy przekazywać przelewem na konto Centrum lub osobiście w siedzibie Centrum.
    <br> Numer konta: ** **** **** **** **** **** ****
    <br> W tytule przelewu prosimy wpisać adres email przypisany do konta, z którego dokonano rezerwacji.
    <br>
    <br>
      </div>
<!--***********************STOPKA**********************		-->
        <footer>
		© FAIS UJ 2017 Joanna Ziobrowska
		</footer>
<!--***********************SKRYPTY**********************		-->  
     <script>
       $(document).ready(function(){
           $(window).bind('scroll', function() {
           var navHeight = $( window ).height() * 0.2;
                 if ($(window).scrollTop() > navHeight) {
                     $('nav').addClass('nav_stala');
                 }
                 else {
                     $('nav').removeClass('nav_stala');
                 }
            });
        });
      </script>
        <script>
          function rozwin_nawigacje() {
              var element =  document.getElementById('nawigacja');
              if (element.className === "nav") {
                  element.className += " responsive";
              } else {
                  element.className = "nav";
              }
          }
</script>

      <script>
        $( "#zaloguj" ).on('click', function() {
                document.getElementById('loguj').style.display='block';
        });
      
        $( "#zamknij" ).on('click', function() {
                document.getElementById('loguj').style.display='none';
        });
        
        $( "#do_rejestracji" ).on('click', function() {
                window.location.href = "rejestracja.php";
        });
           $('input[type="checkbox"]').on('change', function() {
            $(this).siblings('input[type="checkbox"]').prop('checked', false);
        });
      </script>
	</body>
</html>