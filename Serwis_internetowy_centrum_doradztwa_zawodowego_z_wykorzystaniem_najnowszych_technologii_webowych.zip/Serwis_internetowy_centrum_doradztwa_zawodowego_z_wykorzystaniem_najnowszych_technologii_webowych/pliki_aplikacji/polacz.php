<?php

  $serwer = "localhost";
  $db_uzytkownik = "root";
  $db_haslo = "";
  $db_nazwa = "centrum_doradztwa";
    
?>