<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}
?>
<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Kontakt | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
       </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
     <div id="zaloguj_przyciski"> 
       <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span>
       <button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 <!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
      </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
     <nav>
     <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a id="aktywna" href="kontakt.php">Kontakt</a>
        <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
             
<!--***********************KONTAKT**********************		-->
      <div class="kontakt" id="kontakt">
        
    <div class="naglowek">Nasze dane kontaktowe</div>
  
    <br><span class="wyroznij"> Centrum Doradzwa Zawodowego Kraków, ul. ************* ****** </span> 
    <br> tel: 735 313 222
    <br> email: ***********
    <br>
    <br><span class="wyroznij">Godziny otwarcia: </span> 
    <br>Centrum otwarte jest od poniedziałku do soboty w godzinach od 9.00 do 20.00.
    <br>
    <br><span class="wyroznij">Informacje o opłatach: </span>
    <br> Opłaty prosimy przekazywać przelewem na konto Centrum lub osobiście w siedzibie Centrum.
    <br> Numer konta: ** **** **** **** **** **** ****
    <br> W tytule przelewu prosimy wpisać adres email przypisany do konta, z którego dokonano rezerwacji.
    <br>
    <br>
    
    <form class="form_kontakt" action="mail.php" method="post">
    <br>W razie jakichkolwiek niejasności oraz pytań zapraszamy do wysłania nam wiadomości email poprzez poniższy formularz kontaktowy:
    <br>
    <br>
    <input type="text" name="temat" placeholder="Temat" required/><br>
    <textarea type="text" name="tresc" placeholder="Treść wiadomości." required></textarea><br>
    <input type="submit" value="Wyślij" />
    </form>
    <br>
    <br>
    
<?php 
      if(isset($_SESSION['mail'])){
          if($_SESSION['mail'] == true){
            echo '<p style="color:green">Mail został wysłany. </p> <br><br>';
            unset($_SESSION['mail']);
          
          }else{ 
            echo '<p style="color:red"<b>NIE</b> wysłano maila! </p> <br><br>';
            unset($_SESSION['mail']);
          }          
      }
?>
   
      </div>

<!--***********************SKRYPTY**********************		-->  
     <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() >  wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
      </script>
       <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
    </body>
</html>