<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['rezerwacje']) && ($_SESSION['rezerwacje'] == false)){

  if(isset($_GET['id_wizyty'])){
   require_once "polacz.php";

     mysqli_report(MYSQLI_REPORT_STRICT);
    try{

      $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
            throw new Exception(mysqli_connect_errno());

         }else{
          $id_wizyty = trim($_GET['id_wizyty']);
          $data = trim($_GET['data_wizyty']);
          $godzina = trim($_GET['godzina_wizyty']);
          
          $_SESSION['data_wizyty'] = $data;
          $_SESSION['godzina_wizyty']  = $godzina;     
          $id = $_SESSION['id'];
          
          $zapisanie = @$lacze->query("INSERT INTO rezerwacje (id_wizyty, id_uzytkownika) VALUES ('$id_wizyty', '$id')");
          
          $_SESSION['dokonano_rezerwacji'] = true;

          if(!$zapisanie) throw new Exception($lacze->error); 
          
           //pobieram dane odnosnie rezerwacji
          $zapytanie3 = @$lacze->query("SELECT * FROM rezerwacje WHERE id_uzytkownika = '$id'");
           
          if($zapytanie3) {
            $ile_rezerwacji = $zapytanie3->num_rows;
            //czy ten uzytkownik ma juz rezerwację
            if($ile_rezerwacji == 1){
              $rekord4 = $zapytanie3->fetch_assoc();
              $id_wizyty = $rekord4['id_wizyty'];
              
              //pobieram date rezerwacji
              $data_rezerwacji = strtotime($rekord4['data_r']);
              $data_dzis = strtotime("now");
                                        
              if(($data_rezerwacji + (60*60*24*3)) > $data_dzis){
                $_SESSION['czy_usunac_rezerwacje'] = true;
                $_SESSION['id_rezerwacji'] = $rekord4['id_rezerwacji'];
              }else{
                $_SESSION['czy_usunac_rezerwacje'] = false;
              }
            }else{
              $_SESSION['rezerwacje'] = false;
            }
            
          $_SESSION['oplata'] = false;
                     
          $lacze->close();
          $_SESSION['rezerwacje'] = true;
          $_SESSION['data_wizyty'] = $data;
          $_SESSION['godzina_wizyty'] = $godzina;
          unset($_GET['id_wizyty']);
          unset($_GET['data_wizyty']);
          unset($_GET['godzina_wizyty']);
          
          header('Location: zapisy.php');
          }
    
        }
    }catch(Exception $ex){
        echo '<span style="color:red"> Błąd serwera, proszę sprobowac później! </span>';
    }
}
}

if((isset($_SESSION['czy_usunac_rezerwacje'])) && ($_SESSION['czy_usunac_rezerwacje'] == true)){
  
  if(isset($_GET['id_rezerwacji'])){
    
     require_once "polacz.php";

     mysqli_report(MYSQLI_REPORT_STRICT);
    try{

      $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
            throw new Exception(mysqli_connect_errno());

         }else{
          $id_rezerwacji = trim($_GET['id_rezerwacji']);
                      
          $usuniecie = @$lacze->query("DELETE FROM rezerwacje WHERE id_rezerwacji= '$id_rezerwacji'");

          if(!$usuniecie) throw new Exception($lacze->error); 
          $lacze->close();
          
          $_SESSION['rezerwacje'] = false;
          
          unset($_SESSION['data_wizyty']);
          unset($_SESSION['godzina_wizyty']);
          
          $_SESSION['czy_usunac_rezerwacje']= false;
                        
          $_SESSION['usunieto_rezerwacje'] = true;
          header('Location: zapisy.php');
          }

      }catch(Exception $ex){
        echo '<span style="color:red"> Błąd serwera, proszę spróbować później! </span>';
    }
    
    
    
  }
  
}
//else {
//  header('Location: zapisy.php');
//  exit();
//}
?>
