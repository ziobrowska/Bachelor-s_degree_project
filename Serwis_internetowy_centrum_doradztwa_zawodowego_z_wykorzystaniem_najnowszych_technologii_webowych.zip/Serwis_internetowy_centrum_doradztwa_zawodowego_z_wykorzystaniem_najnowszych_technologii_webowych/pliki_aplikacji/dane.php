<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_GET['zmien']) && trim($_GET['zmien']) == "tak"){
  
   require_once "polacz.php";
     mysqli_report(MYSQLI_REPORT_STRICT);
    try{

      $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
            throw new Exception(mysqli_connect_errno());

         }else{
         
          if($_SESSION['opiekun'] == 'NIE'){
            $zmiana = 'TAK';
          }
          if($_SESSION['opiekun'] == 'TAK'){
            $zmiana = 'NIE';
          }
           $id = $_SESSION['id'];
       
        $zamiana = @$lacze->query("UPDATE dorosli SET czy_opiekun = '$zmiana' WHERE id_uzytkownika = '$id'");
        if(!$zamiana) throw new Exception($lacze->error);  
        
          if( $zmiana == 'TAK'){
            $_SESSION['opiekun'] = 'TAK';
         }
          if( $zmiana == 'NIE'){
            $_SESSION['opiekun'] = 'NIE';
         }
          
          unset($_GET['zmien']);
          unset($zmiana);
          header('Location: dane.php'); exit();
        }
      
      }catch(Exception $ex){
        echo '<span style="color:red"> Błąd serwera, proszę sprobowac później! </span>';
    }
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Moje dane | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
     <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 <!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
    </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
  <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a id="aktywna" href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
       <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
             
  <!--***********************Dane**********************		-->
      <div class="dane"> 
        <div class="naglowek">Moje dane</div>
        <br><span class="wyroznij"> Dane podstawowe:</span> <br>
        <?php 
        echo '<b>Imię:</b> '.$_SESSION['imie'].'<br>';
        echo '<b>Nazwisko: </b> '.$_SESSION['nazwisko'].'<br>';
        if($_SESSION['plec'] == 'K'){
          echo '<b>Płeć:</b> Kobieta <br>';
        }
        if($_SESSION['plec'] == 'M'){
          echo '<b>Płeć:</b> Mężczyzna <br>';
        }
        echo '<b>Wiek:</b> '.$_SESSION['wiek'].'<br><br>';
              
        echo '<span class="wyroznij"> Dane kontaktowe:</span> <br>';
        if($_SESSION['telefon'] == 'BRAK'){
               echo '<b>Telefon kontaktowy:</b> - <br>';
            }else{
                echo '</b>Telefon kontaktowy: </b> '.$_SESSION['telefon'].'<br>';
            }
        if($_SESSION['adres'] == 'BRAK'){
               echo '<b>Adres:</b> - <br><br>';
            }else{
              echo '<b>Adres: </b>'.$_SESSION['adres'].'<br><br>';
            }
              
        if($_SESSION['wiek'] > 17){
            echo '<span class="wyroznij">Informacje o zawodzie:</span> <br>';
            if($_SESSION['zawod'] == ''){
               echo '<b>Zawód:</b> - <br>';
            }else{
                echo '<b>Zawód:</b> '.$_SESSION['zawod'].'<br>';
            }
        
            if($_SESSION['wyksztalcenie'] == ''){
               echo '<b>Wykształcenie:</b> - <br><br>';
            }else{
                 echo '<b>Wykształcenie: </b>'.$_SESSION['wyksztalcenie'].'<br><br>';
            }
                
          if(isset($_SESSION['opiekun'])){
            echo '<span class="wyroznij"> Opiekun prawny (TAK lub NIE):</span> <br>';
            echo '<b>Jestem opiekunem prawnym: </b>'.$_SESSION['opiekun'].'<br>';
          }
        }
        
        if($_SESSION['wiek'] < 18){
            echo '<span class="wyroznij">Informacje o edukacji:</span> <br>';
            if($_SESSION['szkola'] == ''){
               echo '<b>Szkoła:</b> - <br>';
            }else{
                echo '<b>Szkoła: </b>'.$_SESSION['szkola'].'<br>';
            }
        }
        ?>
        <br><br><a id="zmien" href="dane.php?zmien=tak"> Zmień uprawnienia opiekuna prawnego </a> 
        <br><br><br><br>
       
      </div>

<!--***********************SKRYPTY**********************		-->  
    <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
      </script>
         <script>
    function rozwin_nawigacje() {
        var element =  document.getElementById('nawigacja');
        if (element.className === "nav") {
            element.className += " zmienna";
        } else {
            element.className = "nav";
        }
    }
</script>
  </body>  
   
</html>