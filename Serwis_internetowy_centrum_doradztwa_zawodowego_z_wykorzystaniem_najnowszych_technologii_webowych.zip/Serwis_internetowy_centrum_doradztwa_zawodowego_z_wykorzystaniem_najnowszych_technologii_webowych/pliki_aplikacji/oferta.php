<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

?>
<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Oferta centrum | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
      </head>
  <body>
<!--***********************Przyciski_góra**********************		-->
       <div id="zaloguj_przyciski"> 
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 <!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego</div>
    </header>
<!--***********************NAWIGACJA**********************		-->
  <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a id="aktywna" href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
       <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav> 
 <!--***********************OFERTA**********************		-->
      <div class="oferta" id="oferta">
        <div class="naglowek">Centrum oferuje:</div>
        <br>
        <div class="wyroznij">Rozmowa diagnostyczna z doradcą zawodowym – 220 zł, 2 godziny zegarowe
        </div>
        Pierwsza rozmowa to rozmowa diagnostyczna, ale bardzo często jest to też rozmowa ostatnia. Zwykle już na pierwszym spotkaniu jesteśmy w stanie rozwiązać Twój problem: wyniki wypełnionego kwestionariusza zdradzają Twoje preferencje zawodowe i zawody dedykowane dla Ciebie. Jeśli zachodzi potrzeba, zapraszamy Cię na kolejne spotkania indywidualne.
        <br>
        
        <br>
        <div class="wyroznij">Spotkanie indywidualne z doradcą zawodowym - 200 zł, 2 godziny zegarowe</div>
          Jeśli stwierdzimy, iż spotkanie dignostyczne to za mało, istnieje możliwość umówienia się na spotkanie indywidualne, o tematyce dopasowanej do Twoich potrzeb.
          <br><br>
          Możliwe tematy takich spotkań to:
        <ul>
          <li>Badanie predyspozycji zawodowych</li>
          <li>Odkrywanie celu zawodowego</li>
          <li>Planowanie rozwoju zawodowego</li>
          <li>Ukazanie możliwości dostępnych na rynku pracy</li>
          <li>Tworzenie wizerunku zawodowego</li>
          <li>Godzenie życia rodzinnego z pracą</li>
          <li>Zmiana pracy lub ścieżki kariery</li>
          <li>Rozwiązywanie problemów w pracy</li>
          <li>Wypalenie zawodowe</li>
        </ul>
        <br>
        <div class="wyroznij">Szkolenie indywidualne - 200 zł, 2 godziny zegarowe</div>
        Szkolenia indywidualnie służą wyrabianiu nowych nawyków oraz ich utrwalaniu.
        <br>
        <br>
        Możliwe tematy takich szkoleń to:
        <ul>
          <li>Przygotowanie do rozmowy kwalifikacyjnej.</li>
          <li>Asertywność w pracy i rozwiązywanie konfliktów.</li>
          <li>Efektywna komunikacja.</li>
          <li>Lepsza organizacja pracy i skuteczna realizacja celów.</li>
        </ul>
        </div>
    <br>
    <br>
    <br>

<!--***********************SKRYPTY**********************		-->  
       <script>
           $(document).ready(function(){
            $(window).bind('scroll', function() {
                var wys_nawigacji = $( window ).height() * 0.2;  
                     if($(window).scrollTop() > wys_nawigacji) {
                      $( "nav").addClass('nav_stala');
                     }
                     else{
                      $( "nav").removeClass('nav_stala');
                     }
                });
            });
      </script>
     <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
  </body>
</html>