<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['kolor'])){
  if($_SESSION['kolor'] != 'NIEBIESKI'){
    header('Location: login.php');
    exit();
  }
}

if(!isset($_SESSION['kolor'])){
  require_once "polacz.php";
    try{
    
    $lacze = new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
    
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
      
    }else{
      $id = $_SESSION['id'];
      
      $wstawienie = $lacze->query("INSERT INTO testy (id_uzytkownika) VALUES ('$id')");
        if($wstawienie){
                
          
          $odpowiedz = $lacze->query("SELECT * FROM testy WHERE id_uzytkownika ='$id'");
            if($odpowiedz) { 

            $rekord = $odpowiedz->fetch_assoc();
              $id_testu = $rekord['id_testu'];
              $_SESSION['kolor'] = 'NIEBIESKI';
              $_SESSION['czy_kwestionariusz'] = true;
              $kolor = $_SESSION['kolor'];
              
              $wstawienie2 = $lacze->query("UPDATE wyniki SET kolor = '$kolor' WHERE id_testu ='$id_testu'");
              
               if($wstawienie2){
               $_SESSION['zapisano_kwestionariusz'] = true;
               }
              else{
                $_SESSION['czy_kwestionariusz'] = false;
                unset($_SESSION['kolor']);
                throw new Exception($lacze->error);
              }

            }else{
              throw new Exception($lacze->error);
            }
              
          }else{
            throw new Exception($lacze->error);
        }
        $lacze->close();
    }
     
  }catch(Exception $ex){
    echo '<span class="komunikat2"> Błąd serwera, proszę spróbować później! </span>';
      header('Location: kwestionariusz.php');
  }
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Twój typ osobowości | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_typ.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
     </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
       <div id="zaloguj_przyciski"> 
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span>
         <button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego</div>
    </header>
<!--***********************NAWIGACJA**********************		-->
  <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a id="aktywna" href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
      <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
           
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
  <?php
      if(isset( $_SESSION['zapisano_kwestionariusz']) && ( $_SESSION['zapisano_kwestionariusz'] == true)){
      echo '<div class="naglowek" style="color:green">Twój wynik został zapisany!</div>';
      unset( $_SESSION['zapisano_kwestionariusz']);
    }
  ?>
      <div class="naglowek"> Twój typ osobowości to Niebieski: Analityk i Organizator </div> 
      Niebieski to styl emocjonalny, skupiony na kontaktach z innymi ludzi. Do rozwoju potrzebuje akceptacji innych. Jest zwykle pesymistą. Ważne jest dla niego zbieranie informacji. Niebieski jest uprzejmy, łagodny, skłonny do współpracy. Doskonale sprawdza sie jako negocjator lub arbitrażysta godzący sprzeczne interesy zwaśnionych stron, idealny we współpracy w zespole. Utalentowany polityk, bystry obserwator. Najwyżej w hierarchi wartości stawia rodzinę i przyjaciół.
      <br> <br> <br>
      <div class="responsywna">
      <table>
      <tr>
        <th> <div id="q">Zalety</div></th>
        <th> <div id="q">Słabe strony </div></th>
      </tr>
      <tr>
        <td> 
          <div id="q">Jako jednostka:</div>
         <ul >
            <li>Traktuje życie bardzo poważnie.</li>
            <li>Docenia piękno i szczegóły.</li>
            <li>Jest stały w uczuciach i można na nim polegać.</li>
            <li>Jest szczery i głęboko emocjonalny.</li>
            <li>Cechuje go analityczny umysł (zastanawia się, dlaczego ludzie zachowują się tak, a nie inaczej).</li>
            <li>Ma silne poczucie sensu życia.</li>
          </ul>
        </td>
          <td> 
            <div id="q">Jako jednostka:</div>
          <ul>
            <li>Jest zbyt emocjonalny.</li>
            <li>Bywa obłudny i fałszywy.</li>
            <li>Kontroluje i /lub zazdrości innym łatwych sukcesów.</li>
            <li>Jest perfekcjonistą.</li>
            <li>Ma o sobie złe zdanie.</li>
          </ul>
        </td>
        </tr>
        
        <tr>
        <td> 
          <div id="q">Jako rozmówca:</div>
          <ul >
            <li>Jest wrażliwy, ceni szczerą rozmowę.</li>
            <li>Wczuwa się w sytuację rozmówcy.</li>
            <li>Pamięta odczucia i myśli towarzyszące rozmowie.</li>
            <li>Nie ponagla rozmówcy.</li>
            <li>Bardziej komfortowo czuje się w małej grupie.</li>
          </ul>
        </td>
          <td> 
            <div id="q">Jako rozmówca:</div>
          <ul >
            <li>Zdarza mu się przegadać lub wykładać dany temat, zamiast o nim dyskutować.</li>
            <li>Ma zdecydowane opinie na wiele tematów.</li>
            <li>Zbyt mocno kieruje się emocjami.</li>
            <li>Wydaje mu się, że inni potrafią czytać w jego myślach i dlatego powinni znać jego uczucia.</li>
            <li>Upiera się przy swoim zdaniu, niechętnie negocjuje.</li>
          </ul>
        </td>
        </tr>
              
        <tr>
        <td> 
          <div id="q">Dążenie do celu:</div>
          <ul >
            <li>Jest zdyscyplinowany.</li>
            <li>Dąży do osiągnięcia celu.</li>
            <li>Dokładnie planuje, a następnie realizuje plan.</li>
          </ul>
        </td>
          <td> 
            <div id="q">Dążenie do celu:</div>
		  <ul >
            <li>Ma bardzo wysokie oczekiwania.</li>
            <li>W razie niepowodzeń szybko się zniechęca.</li>
            <li>Frustruje go brak współpracy w zespole.</li>
          </ul>
          </td>
        </tr>
        
        <tr>
        <td> 
          <div id="q">Jako pracownik:</div>
          <ul >
            <li>Dobrze czuje się jako pracownik „zaplecza”.</li>
            <li>Szanuje pracodawcę ze względu na jego wyższą pozycję zawodową.</li>
            <li>Skupia się na szczegółach i planie.</li>
            <li>Daje z siebie więcej, niż się od niego wymaga.</li>
          </ul>
        </td>
          <td> 
            <div id="q">Jako pracownik:</div>
		  <ul>
            <li>Nie wierzy w swój talent i kreatywność.</li>
            <li>Unika wystąpień publicznych.</li>
            <li>Ma nierealistyczne wymagania względem siebie i innych.</li>
            <li>Ma tendencję do zbytniej szczegółowości.</li>
            <li>Jest krytyczny w stosunku do siebie i innych.</li>
            <li>Bierze na siebie zbyt dużo obowiązków.</li>
          </ul>
          </td>
        </tr>
        </table>
        </div>
		<br> <br>													
		<b>Niebiescy szybko adaptują sią w świecie kariery zawodowej. Praca idealna dla Niebieskiego:</b> 
        <ul>
		<li>Stabilne otoczenie i procedury.</li>
		<li>Praca wymagająca zdolności myślenia analitycznego i krytycznego spojrzenia na wystepujace problemy.</li>
	    <li>Stanowsko wymagające planowania i myślenia strategicznego.</li>
		<li>Praca bez presji czasu i w warunkach maksymalnie bes-stresowych.</li>
		<li>Stanowisko niewymagajace częstych kontaktów międzyludzkich.</li>
        </ul>
      
       <b>Zawody odpowiednie dla Niebieskiego: </b> <br>
		Nauczyciel, Polityk, Architekt, Psychoterapeuta, Informatyk, Muzyk, Bankier, Duchowny, Księgowy, Pielęgniarka, Inżynier, Bibliotekarz, Dziennikarz
    
      <br><br><br><br>
      <div class="zrodlo">
      Opracowano na podstawie: Taylor Hartman, "Kod kolorów. Typy osobowości zaszyfrowane w kolorach.", przekł. Lidia Rafa, Warszawa: Amber 1999 oraz <a href="http://zskesowo.kopi.edu.pl/userfiles/file/beata/kwestionariusz_osobowosciowy_interpretacja_wynikow.pdf">http://zskesowo.kopi.edu.pl</a>
      </div>
      </div>
      <br><br><br>

<!--***********************SKRYPTY**********************		-->  
    <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
      </script>
    <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
    </body> 
</html>