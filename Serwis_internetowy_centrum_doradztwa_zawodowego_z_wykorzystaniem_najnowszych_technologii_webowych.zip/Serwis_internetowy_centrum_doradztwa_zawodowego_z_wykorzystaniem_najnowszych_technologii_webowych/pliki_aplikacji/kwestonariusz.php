<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['czy_kwestionariusz']) && ($_SESSION['czy_kwestionariusz'] != false)){
  header('Location: login.php');
  exit();
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title>Kwestionariusz osobowościowy | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
      <script src="kwestionariusz.js"></script>
  </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
        <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
      </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
 <nav>
    <div id="nawigacja"  class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<aid="aktywna"  href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
      <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
            
          
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
      <div class="naglowek">Kwestionariusz Osobowościowy Hartmana </div><br>
    
    <div id="kwestionariusz_opis">
        <br>
        Dr. Hartman wyróżnił 4 typy osobowości: niebieski, biały, czerwony i żółty. Kolorami oznaczył zbiór wad i zalet charakterystycznych dla danego typu. Do określenia typu osobowości stworzył kwestionariusz osobowościowy.
        <br>
        <br>
        Mało prawdopodne jest, aby wynik, który uzyskasz stanowił stuprocentowo o jednym kolorze. Pozwoli Ci on jednak określić kolor będący dla Ciebie kolorem głównym, wiodącym.
        <br>
        <br>
        Oto kilka sugestii, które ułatwią Ci wypełnienie kwestionariusza: <br>
        1. Odpowiadając na pytania, spróbuj przypommieć sobie jak najwcześniejsze dzieciństwo. Osobowość jest wrodzona, staraj się więc raczej odszukać w sobie cechy pierwotne, niż nabyte. <br>
        2. Najpierw odpowiedź na pytania, co do których nie masz wątpliwości. Do trudniejszych wróć na końcu. <br>
        3. Postaraj się wybierać jak najbardziej typowe dla siebie reakcje. Nie oszukuj się, upiększjąc odpowiedzi. Potencjalna nagroda za szczerość jest warta Twojego wysiłku.
        <br> 
        <br>
        Kwestionariusz rozwiązuje się jednorazowo. Składa się on z 45 pytań. W każdym z nich wybierz stwierdzenie/reakcję, która najbardziej do Ciebie pasuje. Zawsze wybieraj tylko jedną odpowiedź. 
        <br>
        <br>
        <br>
    </div>
    <button id="rozpocznij_kwest">Rozwiąż kwestionariusz</button>
    <div class="kwestionariusz_slajdy" id="zawartosc_kwestionariusza">
    </div>
    <button id="poprzednie_pytanie"> Poprzednie pytanie</button>
    <button id="nastepne_pytanie">Następne pytanie</button>
    <button id="zapisz_odp">Zapisz odpowiedzi</button>
     </div>
 </body>
<!--***********************SKRYPTY**********************		-->  
          <script>
          $(document).ready(function(){
               $(window).bind('scroll', function() {
               var wys_nawigacji = $( window ).height() * 0.2;
                     if ($(window).scrollTop() > wys_nawigacji) {
                         $('nav').addClass('nav_stala');
                     }
                     else {
                         $('nav').removeClass('nav_stala');
                     }
                });
            });
          </script>
         <script>
            function rozwin_nawigacje() {
                  var element =  document.getElementById('nawigacja');
                  if (element.className === "nav") {
                      element.className += " zmienna";
                  } else {
                      element.className = "nav";
                  }
              }
          </script>
  </body>  
</html>