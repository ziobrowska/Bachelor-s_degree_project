<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['kolor'])){
  if($_SESSION['kolor'] != 'BIALY'){
    header('Location: login.php');
    exit();
  }
}

if(!isset($_SESSION['kolor'])){
  require_once "polacz.php";
    try{
    
    $lacze = new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
    
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
     }else{
      $id = $_SESSION['id'];
      
      $wstawienie = $lacze->query("INSERT INTO testy (id_uzytkownika) VALUES ('$id')");
        if($wstawienie){
       
          $odpowiedz = $lacze->query("SELECT * FROM testy WHERE id_uzytkownika ='$id'");
            if($odpowiedz) { 
            $rekord = $odpowiedz->fetch_assoc();
              $id_testu = $rekord['id_testu'];
              $_SESSION['czy_kwestionariusz'] = true;
              $_SESSION['kolor'] = 'BIALY';
              $kolor = $_SESSION['kolor'];
              
              $wstawienie2 = $lacze->query("UPDATE wyniki SET kolor = '$kolor' WHERE id_testu ='$id_testu'");
              
               if($wstawienie2){
                 $_SESSION['zapisano_kwestionariusz'] = true;
               }
              else{
                $_SESSION['czy_kwestionariusz'] = false;
                unset($_SESSION['kolor']);
                throw new Exception($lacze->error);
              }
            }else{
                throw new Exception($lacze->error);
            }
          }else{
            throw new Exception($lacze->error);
        }
        $lacze->close();
    }
     
  }catch(Exception $ex){
    echo '<span class="komunikat2"> Błąd serwera, proszę spróbować później! </span>';
      header('Location: kwestionariusz.php');
  }
}
?>
<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title>Twój typ osobowości | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_typ.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
       
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span>
        <button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
      </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
 <nav>
   <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a id="aktywna" href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
       <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
             
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
        <div id="opis_typu_c"> 
          
  <?php
      if(isset( $_SESSION['zapisano_kwestionariusz']) && ( $_SESSION['zapisano_kwestionariusz'] == true)){
        echo '<div class="naglowek" style="color:green">Twój wynik został zapisany!</div>';
        unset( $_SESSION['zapisano_kwestionariusz']);
      }
  ?>
      <div class="naglowek"> Twój typ osobowościto Biały: Wizjoner i Budowniczy</div>
      Bialy to indywidualista, utalentowany wizjoner, skupiony na swoich marzeniach i planach. Idealista, mało skupiony na detalach, zazwyczaj widzi tylko "szeroki plan". Ma bardzo rozwinietą intuicję. Komunikatywny i lubiany w grupie, pełni role inspirujące. Dzieki niemu grupa rozwija swoje pomysły, plany i idee.
      <br> <br> <br>
          <div class="responsywna">
      <table>
      <tr>
        <th> <div id="q">Zalety</div></th>
        <th> <div id="q">Słabe strony </div></th>
      </tr>
      <tr>
        <th> 
          <div id="q">Jako jednostka:</div>
          <ul >
            <li>Jest spokojny, łagodny i refleksyjny.</li>
            <li>Ma szczery i bezpretensjonalny styl życia.</li>
            <li>Wydaje się naturalnie akceptować życie.</li>
            <li>Jest cierpliwy wobec innych i siebie.</li>
            <li>Ceni proste życie.</li>
            <li>Umie dostosować się do innych.</li>
            <li>Jest dobry dla ludzi i zwierząt.</li>
            <li>Potrafi znaleźć się w każdej sytuacji.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako jednostka:</div>
          <ul>
            <li>Biernie podchodzi do życia.</li>
            <li>Mało spontanicznie i otwarcie reaguje na wydarzenia .</li>
            <li>Jest wstydliwy i niepewny siebie.</li>
            <li>Łatwo nakłonić go do zmiany planów.</li>
            <li>Jest niezdecydowany co do celu i kierunku, w którym zmierza.</li>
            <li>Bywa leniwy i niechętnie bierze na siebie odpowiedzialność.</li>
            <li>Nie angażuje się.</li>
            <li>Jest nudny w swojej obiektywności.</li>
          </ul>
        </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako rozmówca:</div>
          <ul>
            <li>Potrafi zaakceptować punkt widzenia innych ludzi.</li>
            <li>Jest urodzonym negocjatorem i mediatorem w sytuacjach problemowych.</li>
            <li>Jest znakomitym słuchaczem.</li>
            <li>Potrafi się zdobyć na silną empatię.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako rozmówca:</div>
          <ul>
            <li>Obawia się każdej konfrontacji.</li>
            <li>Nie potrafi szybko reagować podczas dyskusji.</li>
            <li>Jest nieszczery w uczuciach -np. zgadza się na coś, by zadowolić innych.</li>
            <li>Niechętnie podejmuje decyzje.</li>
          </ul>
        </th>
        </tr>
              
        <tr>
        <th> 
          <div id="q">Dążenie do celu:</div>
          <ul>
            <li>Jest otwarty na propozycje.</li>
            <li>Lubi mieć duży wybór możliwości.</li>
            <li>Docenia zalety dążenia do celu.</li>
            <li>Wierzy w swoje siły i możliwości.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Dążenie do celu:</div>
		  <ul>
            <li>Jego życiowym mottem jest: "Pożyjemy zobaczymy".</li>
            <li>Czeka na znaki, lub by inni podjęli decyzję za niego.</li>
            <li>Jest niekonsekwentny w dążeniu do osiągnięcia celu.</li>
            <li>Czeka, bu inni wyznaczyli mu cele, a następnie je krytykuje.</li>
          </ul>
          </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako pracownik:</div>
          <ul>
            <li>Dobrze radzi sobie na urzędniczych stanowiskach.</li>
            <li>Jest świetnym negocjatorem.</li>
            <li>Zachowuje zimną krew w sytuacjach stresowych.</li>
            <li>Lubi wolniejsze tempo pracy i zawsze musi mieć czas do namysłu.</li>
            <li>Niekiedy podejmuje ryzykowne zawody, by czuć dreszczyk emocji.</li>
            <li>Umie zadowolic innych.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako pracownik:</div>
		  <ul>
            <li>Unika zwracania na siebie uwagi.</li>
            <li>Jest mało energiczny.</li>
            <li>Nie ma wytyczonego kierunku w życiu - oczekuje, by inni nim kierowali.</li>
            <li>Ma wolne tempo pracy.</li>
            <li>Trudno go zainspirować.</li>
            <li>Obawia się zmian i ryzyka.</li>
            <li>Woli pozostać w tej samej nudnej pracy.</li>
            <li>Gdy nie ma odpowiedniej motywacji, łatwo nim manipulować.</li>
          </ul>
          </th>
        </tr>
        </table>
        </div>
		<br><br>													
		<b> Biali mają najmniejsza motywację, by odnosic sukcesy zawodowe. Praca idealna dla Białego:</b>
        <ul>
		<li>Miejsce pracy z wysokim poczuciem bezpieczeństwa i stabilności.</li>
		<li>Praca musi miec dokladnie okreslone zasady i granice decyzyjności.</li>
		<li>Stanowisko z mozliwością budowania dobrych relacji międzyludzkich..</li>
        <li>Stanowisko ze zmiennym zakresem obowiązkow i szansa uczenia się.</li>
		</ul>
      
          <b>Zawody odpowiednie dla Białego: </b><br>
		Leśnik, Dentysta, Urzędnik, Informatyk, Wojskowy, Organizator wypoczynku, Badacz, Prawnik, Oficer policji, Przedszkolanka, Weterynarz, Inżynier, Agent służb specjalnych, Kierowca ciężarówki
    
       <br><br><br><br>
      <div class="zrodlo">
      Opracowano na podstawie: Taylor Hartman, "Kod kolorów. Typy osobowości zaszyfrowane w kolorach.", przekł. Lidia Rafa, Warszawa: Amber 1999 oraz <a href="http://zskesowo.kopi.edu.pl/userfiles/file/beata/kwestionariusz_osobowosciowy_interpretacja_wynikow.pdf">http://zskesowo.kopi.edu.pl</a>
      </div></div><br><br><br>

<!--***********************SKRYPTY**********************		-->  
    <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
      </script>
        <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
    </body> 
</html>