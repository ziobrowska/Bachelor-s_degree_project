<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['kolor'])){
  if($_SESSION['kolor'] != 'CZERWONY'){
    header('Location: login.php');
    exit();
  }
}

if(!isset($_SESSION['kolor'])){
  require_once "polacz.php";
    try{
    
    $lacze = new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
      
    }else{
      $id = $_SESSION['id'];
      
      $wstawienie = $lacze->query("INSERT INTO testy (id_uzytkownika) VALUES ('$id')");
        if($wstawienie){
          $odpowiedz = $lacze->query("SELECT * FROM testy WHERE id_uzytkownika ='$id'");
            if($odpowiedz) { 
              $rekord = $odpowiedz->fetch_assoc();
              $id_testu = $rekord['id_testu'];
              $_SESSION['czy_kwestionariusz'] = true;
              $_SESSION['kolor'] = 'CZERWONY';
              $kolor = $_SESSION['kolor'];
              
              $wstawienie2 = $lacze->query("UPDATE wyniki SET kolor = '$kolor' WHERE id_testu ='$id_testu'");
              
               if($wstawienie2){
               $_SESSION['zapisano_kwestionariusz'] = true;
               }
              else{
                $_SESSION['czy_kwestionariusz'] = false;
                unset($_SESSION['kolor']);
                throw new Exception($lacze->error);
              }

            }else{
              throw new Exception($lacze->error);
            }
                    
          }else{
            throw new Exception($lacze->error);
        }
        $lacze->close();
    }
     
  }catch(Exception $ex){
    echo '<span class="komunikat2"> Błąd serwera, proszę spróbować później! </span>';
      header('Location: kwestionariusz.php');
  }
}
?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Twój typ osobowości | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_typ.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
  </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
      <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span>
        <button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
<nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'MIX'){
          echo '<a id="aktywna" href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
      <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
   <?php
      if(isset( $_SESSION['zapisano_kwestionariusz']) && ( $_SESSION['zapisano_kwestionariusz'] == true)){
      echo '<div class="naglowek" style="color:green">Twój wynik został zapisany!</div>';
      unset( $_SESSION['zapisano_kwestionariusz']);
    }
  ?>
      <div class="naglowek"> Twój typ osobowości to Czerwony: Przywódca </div> <br>
      Czerwony jest logiczny, praktyczny i zamknięty w sobie. To silna, zdecydowana osobowośc. Bywa trudny w kontaktach międzyludzkich. Naturalny lider, dominujący i gwałtowny w reakcjach. Ma potrzebę kontrolowania sytuacji i przewidywania efektów swoich działań.
       <br> <br><br>
      <div class="responsywna">
      <table>
      <tr>
        <th> <div id="q">Zalety</div></th>
        <th> <div id="q">Słabe strony </div></th>
      </tr>
      <tr>
        <th> 
          <div id="q">Jako jednostka: </div>
          <ul >
            <li>Wyróznia sie logicznym myśleniem.</li>
		    <li>Ceni produktywny styl życia.</li>
		    <li>Ceni niezależność.</li>
		    <li>Jest pomysłowy i zaradny.</li>
            <li>Jest dynamiczny i bezpośredni.</li>
		    <li>Twórczo podchodzi do problemów.</li>
            <li>Jest urodzonym przywódcą.</li> 
          </ul>
        </th>
          <th> 
            <div id="q">Jako jednostka: </div>
          <ul>
	       <li>Troszczy się o własną satysfakcję (a co ja z tego będę mieć?).</li>
		    <li>Dla osobistych korzyści nie waha się wdać w konflikty.</li>
            <li>Racjonalizuje i wypiera się uczuć.</li>
            <li>Ma zawsze rację.</li>
            <li>Nie potrafi się zrelaksować i zawsze musi coś robić.</li>
            <li>Jest arogancki i lekceważy zwierzchników.</li>
            <li>Nie szanuje uczuć innych.</li>
            <li>Nie przyznaje się do braku odpowiednich umiejętności, gdyż obawia się, że straci władzę.</li>
          </ul>
        </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako rozmówca: </div>
          <ul>
            <li>Posługuje się bardzo logicznymi argumentami.</li>
		    <li>Szczerze i otwarcie wyraża swoje opinie.</li>
		    <li>Ma łatwość wysławiania się.</li>
		    <li>Potrafi poprowadzić dyskusję w efektywnym i praktycznym kierunku.</li>
            <li>Jasno określa swój stosunek do partnerów.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako rozmówca:</div>
          <ul >
		    <li>Nie uświadamia sobie uczuć, tłumi emocje.</li>
            <li>Jest niewrażliwy i nietaktowny.</li>
            <li>Niepewność zagłusza jego intuicję.</li>
		    <li>Szybko nudzi się ,,próżnym gadaniem''.</li>
		    <li>Jest surowy w wydawaniu osądów.</li>
		    <li>Nie potrafi słuchać.</li>
		  </ul>
        </th>
        </tr>
              
        <tr>
        <th> 
          <div id="q">Dążenie do celu:</div>
          <ul>
            <li>Potrafi dokładnie i precyzyjnie określić, do czego dąży.</li>
		    <li>Patrzy perspektywicznie.</li>
		    <li>Jest zdyscyplinowany.</li>
		    <li>Jest produktywny.</li>
		    <li>Szybko i z łatwością podejmuje decyzje.</li>
		    <li>Dąży do realizacji celów.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Dążenie do celu: </div>
		  <ul >
		    <li>Niecierpliwi się dochodzeniem do celu.</li>
		    <li>Ma zbyt wysokie oczekiwania wobec losu.</li>
            <li>Żyje "na niby", zamist z ludźmi.</li>
		    <li>Stawia na ilość, zamiast na jakość.</li>
		    <li>Przeszkody i trudności w realizacji zamierzeń wyprowadzają go z równowagi.</li>
		    <li>Obwinia innych za swoje niepowodzenia.</li>
		  </ul>
          </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako pracownik:</div>
          <ul >
            <li>Pociąga go pozycja przywódcy.</li>
            <li>Dobrze się czuje mając władzę.</li>
		    <li>Jest znakomitym organizatorem.</li>
		    <li>Doskonale rozdziela obowiązki.</li>
		    <li>Szybko podejmuje decyzje i dobrze wypełnia powierzone mu zadanie.</li>
		    <li>Ma silną motywację.</li>
		    <li>Lubi rywalizować.</li>
		    <li>Jest dynamiczny i asertywny.</li>
            <li>Motywuje go współzawodnictwo.</li>
		    <li>Wierzy w swoje możliwości.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako pracownik:</div>
		  <ul >
		    <li>Niechętnie odpoczywa, zmusza do pracy siebie i innych.</li>
		    <li>Nie lubi, by mówiono mu, co ma robić.</li>
		    <li>Jest niewrażliwy, gdy dąży do osiągnięcia sukcesu w interesach.</li>
            <li>Zbyt pochopnie podejmuje decyzje.</li>
		    <li>Nie traci czasu na przemyślenie problemu, nigdy nie pyta o radę.</li>
		    <li>Bardziej interesuje go zadanie niż ludzie.</li>
            <li>Wymaga od innych lojalności i posłuszeństwa.</li>
		    <li>Jest bezkompromisowy i apodyktyczny.</li>
		    <li>Jest oszczędny w pochwałach, raczej krytykuje.</li>
		</ul>
          </th>
        </tr>
        </table>
        </div>
		<br><br>												
		<b>Dla Czerwonych rzeczą naturalną jest dażenie do sukcesu zawodowego.<br>
          Praca idealna dla Czerwonego:</b>
        <ul>
		<li>Stanowisko wymagające łączenia wielu zadań i umiejętności.</li>
		<li>Praca z możliwościa awansu i uznania.</li>
		<li>Praca ze swobodą działania i podejmowania decyzji.</li>
		<li>Stanowisko pozwalające na pełne kontrolowanie efektów własnej pracy.</li>
		<li>Praca bez zadań powtarzalnych i rutynowych.</li>
		</ul>
      
       <b>Zawody odpowiednie dla Czerwonego:</b><br>
		Polityk, Prawnik, Sprzedawca, Duchowny, Oficer, Agent w handlu nieruchomościami, Pracownik działu marketingu, Krytyk, Majster budowlany, Woźny, Lekarz, Doradca podatkowy, Administrator, Policjant
    
       <br><br><br><br>
      <div class="zrodlo">
      Opracowano na podstawie: Taylor Hartman, "Kod kolorów. Typy osobowości zaszyfrowane w kolorach.", przekł. Lidia Rafa, Warszawa: Amber 1999 oraz <a href="http://zskesowo.kopi.edu.pl/userfiles/file/beata/kwestionariusz_osobowosciowy_interpretacja_wynikow.pdf">http://zskesowo.kopi.edu.pl</a>
      </div>
       </div>
      <br><br><br>
  <!--***********************SKRYPTY**********************		-->  
        <script>
         $(document).ready(function(){
             $(window).bind('scroll', function() {
             var wys_nawigacji = $( window ).height() * 0.2;
                   if ($(window).scrollTop() > wys_nawigacji) {
                       $('nav').addClass('nav_stala');
                   }
                   else {
                       $('nav').removeClass('nav_stala');
                   }
              });
});
        </script>
        <script>
          function rozwin_nawigacje() {
              var element =  document.getElementById('nawigacja');
              if (element.className === "nav") {
                  element.className += " zmienna";
              } else {
                  element.className = "nav";
              }
          }
        </script>
    </body> 
</html>