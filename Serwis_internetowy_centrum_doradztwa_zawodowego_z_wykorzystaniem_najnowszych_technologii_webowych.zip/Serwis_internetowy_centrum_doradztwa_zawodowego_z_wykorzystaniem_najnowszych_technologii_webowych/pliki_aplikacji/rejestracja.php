<?php
session_start();

if(isset($_POST['email'])){
  
  //waldacja formularza na tak
  $walidacja = true;
  
  //sprawdzam checkboxy
  if((!isset($_POST['mezczyzna'])) && (!isset($_POST['kobieta']))){
      $walidacja = false;
      $_SESSION['blad_plec']='<span style="color:red"> Nie zaznaczyłeś/łaś płci! </span>';
  }
  
  if(isset($_POST['mezczyzna'])){
    $plec = 'M';
  }else{
     $plec = 'K';
  }
    
  //sprawadzam email
  $email = $_POST['email'];
  $email_zwalidowany = filter_var($email, FILTER_SANITIZE_EMAIL);
  
  if((filter_var($email_zwalidowany, FILTER_VALIDATE_EMAIL)==false) || ($email_zwalidowany!=$email)){
    $walidacja = false;
    $_SESSION['blad_email']='<span style="color:red"> Podaj poprawny adres email! </span>';
   }
  
  //sprawadzam hasla
  $haslo1 = $_POST['haslo1'];
  $haslo2 = $_POST['haslo2'];
  
  if((strlen($haslo1)<8) || (strlen($haslo1)>20)){
    $walidacja=false;
    $_SESSION['blad_haslo']='<span style="color:red"> Hasło musi posiadać od 8 do 20 znaków! </span>';
  }
  
  if($haslo1!=$haslo2){
    $walidacja=false;
    $_SESSION['blad_haslo']='<span style="color:red"> Hasła nie są takie same! </span>';
  }
  
  $haslo_haszowane = password_hash($haslo1, PASSWORD_DEFAULT);
  
  
  //sprawadzam imie
    $imie = $_POST['imie'];
  if((strlen($imie)<2) || (strlen($imie)>20)){
    $walidacja=false;
    $_SESSION['blad_imie']='<span style="color:red"> Imię musi posiadać od 8 do 20 znaków! </span>';
  }
  
  //sprawadzam nazwisko
  $nazwisko = $_POST['nazwisko'];
  if(strlen($nazwisko)<2){
    $walidacja=false;
    $_SESSION['blad_nazwisko']='<span style="color:red"> Nazwisko musi posiadać co najmniej 2 znaki! </span>';
  }
  
  //sprawdzam wiek
  $wiek = $_POST['wiek'];
  if((($wiek) < 5) || (($wiek)>100)){
    $walidacja=false;
    $_SESSION['blad_wiek']='<span style="color:red"> Podaj prawidłowy wiek! </span>';
  }

  
  if((($wiek) < 18) && ($_POST['email_d'] == "")){
    $walidacja = false;
    $_SESSION['blad_email_d']='<span style="color:red"> Podaj adres email zarejestrowanego opiekuna prawnego! </span>';
  }
  
  //sprawadzam email doroslego
  if($_POST['email_d'] != ""){
    $email_d = $_POST['email_d'];
    $email_zwalidowany_d = filter_var($email_d, FILTER_SANITIZE_EMAIL);

    if((filter_var($email_zwalidowany_d, FILTER_VALIDATE_EMAIL)==false) || ($email_zwalidowany_d!=$email_d)){
      $walidacja = false;
      $_SESSION['blad_email_d']='<span style="color:red"> Podaj poprawny adres email! </span>';
     }
  }
  
  //kod do reCAPTCHA
  $kod = "6LfiPS0UAAAAAAY6L6ocjKaUTV12d158Frpkc4LM";
  
  //sprawdz reCAPTCHA
  $potwierdzenie = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$kod.'&response='.$_POST['g-recaptcha-response']);
  
  $odpowiedz_google = json_decode($potwierdzenie);
  
  if(!($odpowiedz_google->success)){
     $walidacja = false;
    $_SESSION['blad_boot']='<span style="color:red"> Potwierdź, że nie jesteś bootem! </span>';
  }
  
  
  //sprawdzam regulamin
  if((!isset($_POST['regulamin']))){
      $walidacja = false;
      $_SESSION['blad_regulamin']='<span style="color:red"> Zaakceptuj regulamin! </span>';
  }
  
  
  //zapamietuje dane 
  $_SESSION['zapamietaj_imie'] = $imie;
  $_SESSION['zapamietaj_nazwisko'] = $nazwisko;
  $_SESSION['zapamietaj_wiek'] = $wiek;
  $_SESSION['zapamietaj_haslo1'] = $haslo1;
  $_SESSION['zapamietaj_haslo2'] = $haslo2;
  $_SESSION['zapamietaj_email'] = $email;
  
  if($_POST['email_d'] != ""){
  $_SESSION['zapamietaj_email_d'] = $email_d;
  }
  
  if(isset($_POST['regulamin'])){
    $_SESSION['zapamietaj_regulamin'] = true;
  }
  if(isset($_POST['mezczyzna'])){
    $_SESSION['zapamietaj_mezczyzna'] =true;
  }
  
  if(isset($_POST['kobieta'])){
    $_SESSION['zapamietaj_kobieta'] = true;
  }
    
  
  //lacze sie z bazą
  require_once "polacz.php";
  
  mysqli_report(MYSQLI_REPORT_STRICT);

  try{
    
    $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
        
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
      
    }else{
     //sprawdzam email w bazie
      $odpowiedz = @$lacze->query("SELECT * FROM uzytkownicy WHERE email_u = '$email'");
      
      if(!$odpowiedz) throw new Exception($lacze->error); 
      
      $ilu_uzytkownikow = $odpowiedz->num_rows;
      
      if($ilu_uzytkownikow > 0){
        $walidacja = false;
        $_SESSION['blad_email']='<span style="color:red"> Istnieje już użytkownik z takim emailem! Podaj inny! </span>';
      }
      
      //sprawdzam, czy opiekun wyraził zgode
      $rekord1 = $odpowiedz->fetch_assoc();
      $id_uzytkownika = $rekord1['id_uzytkownika'];
      
      $odpowiedz2 = $lacze->query("SELECT * FROM dorosli WHERE id_uzytkownika = '$id_uzytkownika'");
      
      if(!$odpowiedz2) throw new Exception($lacze->error); 
      
      $rekord2 = $odpowiedz2->fetch_assoc();
      $czy_opiekun = $rekord2['czy_opiekun'];
      
      if($czy_opiekun == 'NIE'){
        $walidacja = false;
        $_SESSION['blad_email_d']='<span style="color:red"> Ten opiekun nie wyraził zgody na przypisanie do siebie małoletniego! </span>';
      }
      
       //jesli wszytsko jest ok
      if($walidacja == true){
        //wstaw do bazy 
        if ($_POST['email_d'] == ""){
          
          $wstawienie = $lacze->query("INSERT INTO uzytkownicy (imie, nazwisko, plec, wiek, email_u, haslo) VALUES ('$imie', '$nazwisko', '$plec', '$wiek', '$email','$haslo_haszowane')");
          
          if($wstawienie){
            $_SESSION['udana_rejestracja'] = true;
            header('Location: powitanie.php');
          }else{
            throw new Exception($lacze->error);
          }
          
          
        } else{
          
         $wstawienie = $lacze->query("INSERT INTO uzytkownicy (imie, nazwisko, plec, wiek, email_u, haslo, email_u_d) VALUES ('$imie', '$nazwisko', '$plec', '$wiek', '$email','$haslo_haszowane', '$email_d')");
          
          if($wstawienie){
            $_SESSION['udana_rejestracja'] = true;
            header('Location: powitanie.php');
          }else{
            throw new Exception($lacze->error);
          }
        }
      }
        $lacze->close();
    }
     
  }catch(Exception $ex){
    echo '<span style="color:red"> Błąd serwera, proszę sprobowac później! </span>';
  }
}

?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title>Rejestracja | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Centrum Doradztwa Zawodowego. Z nami dowiesz sie, jaki zawód jest Ci pisany!">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_indeks.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
      <script src='https://www.google.com/recaptcha/api.js'></script>
      
    </head>
    <body>
<!--***********************Zarejestruj się**********************		-->
 <div class="zarejestruj" id="zarejestruj"> 
      <form class="formularz_rejestracji" action="rejestracja.php" method="post"> 
    
    <div id="naglowek"> Rejestracja w serwisie Centrum Doradztwa Zawodowego</div>
     <div id="zamknij2" class="zamknij" title="Powrót do strony główej">&times;</div> 
    <div id='polecenie' > Wpisz odpowiednie dane </div>
    <div id='formularz_rejestracji'> 
       
      
      
      <div id="plec">
         <input type="checkbox" name="kobieta"<?php  
             if(isset($_SESSION['zapamietaj_kobieta'])){
                 echo "checked";
                unset($_SESSION['zapamietaj_kobieta']);
              }
          ?>  /> Kobieta
        
        <input type="checkbox" name="mezczyzna" 
          <?php  
             if(isset($_SESSION['zapamietaj_mezczyzna'])){
                echo "checked";
                unset($_SESSION['zapamietaj_mezczyzna']);
              }
          ?>/>  Mężczyzna 
      </div> 
      <?php 
      if (isset($_SESSION['blad_plec'])){
        echo $_SESSION['blad_plec'].'<br><br>';
        unset($_SESSION['blad_plec']);
      }
      ?>
      
      
    <label>Email:</label> <br>
    <input type="text" placeholder="np. jankowalski@gmail.com" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_email'])){
                echo $_SESSION['zapamietaj_email'];
                unset($_SESSION['zapamietaj_email']);
              }
          ?>" name="email" required/>
      <br>
      <?php 
      if (isset($_SESSION['blad_email'])){
        echo $_SESSION['blad_email'].'<br><br>';
        unset($_SESSION['blad_email']);
      }
      ?>  
      
      
    <label>Hasło:</label><br>
    <input type="password" placeholder="co najmniej 8 znaków" name="haslo1" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_haslo1'])){
                echo $_SESSION['zapamietaj_haslo1'];
                unset($_SESSION['zapamietaj_haslo1']);
              }
          ?>" required/>
      <br>
      <?php 
      if (isset($_SESSION['blad_haslo'])){
        echo $_SESSION['blad_haslo'].'<br><br>';
        unset($_SESSION['blad_haslo']);
      }
      ?>
      
      
    <label>Powtórz hasło:</label><br>
    <input type="password" placeholder="potwierdz hasło" name="haslo2" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_haslo2'])){
                echo $_SESSION['zapamietaj_haslo2'];
                unset($_SESSION['zapamietaj_haslo2']);
              }
          ?>" required/>
      <br>
      <?php 
      if (isset($_SESSION['blad_haslo'])){
        echo $_SESSION['blad_haslo'].'<br><br>';
        unset($_SESSION['blad_haslo']);
      }
      ?>
      
      
    <label>Imię:</label><br>
    <input type="text" placeholder="imię" name="imie" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_imie'])){
                echo $_SESSION['zapamietaj_imie'];
                unset($_SESSION['zapamietaj_imie']);
              }
          ?>"  required/>
      <br>
      <?php 
      if (isset($_SESSION['blad_imie'])){
        echo $_SESSION['blad_imie'].'<br><br>';
        unset($_SESSION['blad_imie']);
      }
      ?>
      
      
    <label>Nazwisko:</label><br>
    <input type="text" placeholder="nazwisko" name="nazwisko" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_nazwisko'])){
                echo $_SESSION['zapamietaj_nazwisko'];
                unset($_SESSION['zapamietaj_nazwisko']);
              }
          ?>" required/>
       <br>
    <?php 
      if (isset($_SESSION['blad_nazwisko'])){
        echo $_SESSION['blad_nazwisko'].'<br><br>';
        unset($_SESSION['blad_nazwisko']);
      }
      ?>
      
      
    <label>Wiek:</label><br>
    <input type="text" placeholder="wiek" name="wiek" 
           value="<?php  
             if(isset($_SESSION['zapamietaj_wiek'])){
                echo $_SESSION['zapamietaj_wiek'];
                unset($_SESSION['zapamietaj_wiek']);
              }
          ?>" required/>
       <br>
      <?php 
      if (isset($_SESSION['blad_wiek'])){
        echo $_SESSION['blad_wiek'].'<br><br>';
        unset($_SESSION['blad_wiek']);
      }
      ?>
      
      <label>Email opiekuna prawnego (podają tylko osoby nieletnie):</label> <br>
      <input type="text" placeholder="email opiekuna prawnego" name="email_d" 
             value="<?php  
             if(isset($_SESSION['zapamietaj_email_d'])){
                echo $_SESSION['zapamietaj_email_d'];
                unset($_SESSION['zapamietaj_email_d']);
              }
          ?>" />
      <br> 
      <?php 
      if (isset($_SESSION['blad_email_d'])){
        echo $_SESSION['blad_email_d'];
        unset($_SESSION['blad_email_d']);
      }
      ?>
      
     <br><br>
      <div class="g-recaptcha" data-sitekey="6LfiPS0UAAAAAE6w8HiNbYGXqQH9Ge_y3b26jQ1z"></div>

       <?php 
      if (isset($_SESSION['blad_boot'])){
        echo $_SESSION['blad_boot'].'<br>';
        unset($_SESSION['blad_boot']);
      }
      ?>
       <br>     
      <div id="ikony_pod">
      <input type="checkbox" name="regulamin" <?php  
             if(isset($_SESSION['zapamietaj_regulamin'])){
                echo "checked";
                unset($_SESSION['zapamietaj_regulamin']);
              }
          ?> /> Akceptuję regulamin &nbsp;&nbsp;&nbsp;
            <?php 
      if (isset($_SESSION['blad_regulamin'])){
        echo $_SESSION['blad_regulamin'].'    ';
        unset($_SESSION['blad_regulamin']);
      }
      ?>
         
      <input type="submit" value="Zarejestruj mnie">
        
      <br>
      </div>
    <span id='do_logowania'> Masz juz konto? Zaloguj się! </span>
    </div>
         </form>
      </div>  
      
      <script>
       $( "#zamknij2" ).on('click', function() {
                 window.location.href = "index.php";
        });
      $( "#do_logowania" ).on('click', function() {
                window.location.href = "powitanie.php";
       });
       $('input[type="checkbox"]').on('change', function() {
            $(this).siblings('input[type="checkbox"]').prop('checked', false);
        });</script>
  </body>
  
</html>