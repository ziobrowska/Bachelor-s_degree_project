<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Archiwum spotkań | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
     <div id="zaloguj_przyciski"> 
  <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 <!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
      </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
 <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a id="aktywna" href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
        <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav> 
  <!--***********************START**********************		-->
      <div class="start" id="start">
        
        <div class="naglowek">Archiwum odbytych spotkań</div>
       
<?php
 //lacze sie z bazą
    require_once "polacz.php";

      mysqli_report(MYSQLI_REPORT_STRICT);

      try{

        $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
          throw new Exception(mysqli_connect_errno());

        }else{
          $id = $_SESSION['id'];
          $odpowiedz = @$lacze->query("SELECT * FROM historia WHERE id_uzytkownika = '$id'");

          if(!$odpowiedz) throw new Exception($lacze->error); 

          $historia = $odpowiedz->num_rows;

          if($historia > 0){
          echo '<div class="responsywna">';
          echo "<table>";
          echo'<tr> <th>Data</th> <th>Godzina</th> <th>Doradca</th> </tr>';
            while($rekord = $odpowiedz->fetch_assoc()) {
                $data = strtotime($rekord["data"]);
                $data2 = date('d.m.Y', $data);
                $czas2 = date('H:i', $data);
              
                echo "<tr>"; 
                echo "<td>".$data2."r.</td>";
                echo '<td>'.$czas2.'</td>';
                echo'<td>'.$rekord["dane_doradcy"].'</td>';
                echo "</tr>"; 
            } 
            echo "</table>";
            echo "</div>";
         }else{
            echo '<br> <br> <br><div class="wyroznij2"> <b> Twoje archiwum jest puste. </b> </div>';
          }
          $lacze->close();
        }

          }catch(Exception $ex){
          echo '<span style="color:red"> Błąd serwera, proszę spróbować później! </span>';
          }        
?>
      </div>
  <br><br><br> <br><br><br>
<!--***********************SKRYPTY**********************		-->  
      <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
      </script>
       <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
      </body>
</html>