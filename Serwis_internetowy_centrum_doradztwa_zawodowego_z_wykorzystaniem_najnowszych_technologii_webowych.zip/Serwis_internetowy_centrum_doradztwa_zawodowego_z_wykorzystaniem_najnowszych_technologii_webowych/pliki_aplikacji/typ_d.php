<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_SESSION['kolor'])){
  if($_SESSION['kolor'] != 'ZOLTY'){
    header('Location: login.php');
    exit();
  }
}

if(!isset($_SESSION['kolor'])){
  require_once "polacz.php";
    try{
    
    $lacze = new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
    
    if($lacze->connect_errno!=0){
      throw new Exception(mysqli_connect_errno());
      
    }else{
      $id = $_SESSION['id'];
      
      $wstawienie = $lacze->query("INSERT INTO testy (id_uzytkownika) VALUES ('$id')");
        if($wstawienie){
          $_SESSION['czy_kwestionariusz'] = true;
          
          $odpowiedz = $lacze->query("SELECT * FROM testy WHERE id_uzytkownika ='$id'");
            if($odpowiedz) { 

            $rekord = $odpowiedz->fetch_assoc();
              $id_testu = $rekord['id_testu'];
              $_SESSION['kolor'] = 'ZOLTY';
              
              $kolor = $_SESSION['kolor'];
              
              $wstawienie2 = $lacze->query("UPDATE wyniki SET kolor = '$kolor' WHERE id_testu ='$id_testu'");
              
               if($wstawienie2){
                $_SESSION['zapisano_kwestionariusz'] = true;
               }
              else{
                $_SESSION['czy_kwestionariusz'] = false;
                unset($_SESSION['kolor']);
                throw new Exception($lacze->error);
              }

            }else{
              throw new Exception($lacze->error);
            }
          
          }else{
            throw new Exception($lacze->error);
        }
        $lacze->close();
    }
  }catch(Exception $ex){
    echo '<span class="komunikat2"> Błąd serwera, proszę spróbować później! </span>';
      header('Location: kwestionariusz.php');
  }
}
?>
<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Twój typ osobowości | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Kwestionariusz osobowościowy Hartmana. Dowiedz sie jakim typem osobowości jesteś">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_typ.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
    </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego</div>
    </header>
<!--***********************NAWIGACJA**********************		-->
 <nav>
   <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a id="aktywna" href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a id="aktywna" href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a id="aktywna" href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a id="aktywna" href="typ_d.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'MIX'){
          echo '<a id="aktywna" href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a id="aktywna" href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
     <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
<!--***********************KWESTIONARIUSZ HARTMANA**********************		-->
    <div class="kwestionariusz_calosc">
    <div id="opis_typu_d"> 
      
  <?php
      if(isset( $_SESSION['zapisano_kwestionariusz']) && ( $_SESSION['zapisano_kwestionariusz'] == true)){
        echo '<div class="naglowek" style="color:green">Twój wynik został zapisany!</div>';
        unset( $_SESSION['zapisano_kwestionariusz']);
      }
  ?>
   <div class="naglowek"> Twój typ osobowości to Żółty: Pomysłodawca, kreator nowych idei</div>
      Żółty to optymista, radosny i pewny siebie. Lubi dobrą zabawę i nowe wyzwania. Bardzo kreatywny, innowator. Otwarty na nowe doświadczenia, nie boi się zmian. 
      <br> <br> <br>
      <div class="responsywna">
      <table>
      <tr>
        <th> <div id="q">Zalety</div></th>
        <th> <div id="q">Słabe strony</div> </th>
      </tr>
      <tr>
        <th> 
          <div id="q">Jako jednostka:</div>
          <ul >
            <li>Jest optymistyczny (rzadko miewa depresję). </li>
            <li>Lubi siebie i bez trudu akceptuje innych.</li>
            <li>Jest otwarty na nowe możliwości.</li>
            <li>Traktuje życie jako nieustającą zabawę.</li>
            <li>Jest błyskotliwy.</li>
            <li>Lubi przygody i wyzwania.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako jednostka:</div>
          <ul>
            <li>Bardzo zależy mu na robieniu dobrego wrażenia na otoczeniu.</li>
            <li>Dużo mówi, mało robi.</li>
            <li>Za wszelką cenę stara się unikać cierpienia.</li>
            <li>Jest niezdyscyplinowany.</li>
            <li>Unika stwiania czoła problemom.</li>
          </ul>
        </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako rozmówca:</div>
          <ul >
            <li>Szybko myśli, potrafi spontanicznie wyrażać swoje opinie.</li>
            <li>Lubi kontakt fizyczny (uściski, dotyki).</li>
            <li>Łatwo nawiązać z nim rozmowę.</li>
            <li>Podczas dyskusji potrafi jasno się wyrażać.</li>
            <li>Ma dużo energii w kontaktach grupowych.</li>
            <li>Znakomicie radzi sobie w rozmowach ,,o niczym''.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako rozmówca:</div>
          <ul >
            <li>Często mówi, zanim zdąży pomyśleć.</li>
            <li>Żartuje w niewybredny sposób na temat poważnych i drażliwych spraw.</li>
            <li>Jest lekkomyślny i powierzchowny.</li>
            <li>Przerywa innym.</li>
            <li>Wyraża się w bardzo ekspresyjny sposób.</li>
            <li>Nie potrafi słuchać.</li>
          </ul>
        </th>
        </tr>
              
        <tr>
        <th> 
          <div id="q"> Dążenie do celu:</div>
          <ul >
            <li>Żyje chwilą.</li>
            <li>Zawsze daje pierwszeństwo rozrywce.</li>
            <li>Łatwo się przystosowuje.</li>
            <li>Akceptuje innych jako przewodników.</li>
            <li>Jest zdyscyplinowany tylko wtedy, gdy uzna zadanie za zabawne lub wyzywające.</li>
            <li>Woli działać niż myśleć.</li>
        </ul>
        </th>
          <th> 
            <div id="q">Dążenie do celu:</div>
		  <ul>
            <li>Brak mu dyscypliny i zaangażowania w tym, co robi.</li>
            <li>Zamiast myśleć o jutrze, woli się dziś dobrze bawić.</li>
            <li>Nie odczuwa potrzeby planowania przyszłości.</li>
            <li>Szybko się niecierpliwi, nie potrafi skupiać się przez dłuższy czas na jednej czynności.</li>
            <li>Jest niezorganizowany i rozproszony.</li>
        </ul>
          </th>
        </tr>
        
        <tr>
        <th> 
          <div id="q">Jako pracownik:</div>
          <ul>
            <li>Ceni towarzystwo.</li>
            <li>Jest przyjazny.</li>
            <li>Lubi podejmować ryzyko.</li>
            <li>Jest energiczny.</li>
            <li>Zachęc kolegów i pracowników da współpracy i współzawodnictwa.</li>
            <li>Jest charyzmatyczny, przyjemnie z nim pracować.</li>
            <li>Burzy monotonię pracy.</li>
            <li>Lubi podejmować krótkoterminowe zobowiązania, gdzie efekty są natychmiast widoczne. </li>
            <li>Lubi dobrze wyglądać, ale nie ma problemu nosząc ubranie robocze.</li>
            <li>Polega na swojej intuicji, idzie za głosem marzeń.</li>
          </ul>
        </th>
          <th> 
            <div id="q">Jako pracownik:</div>
		  <ul>
            <li>Oczekuje, że każda czynność sprawi mu przyjemność.</li>
            <li>Nie potrafi się skoncentrować.</li>
            <li>Niewiele spraw traktuje poważnie.</li>
            <li>Nie radzi sobie ze stresem.</li>
            <li>Jest nieprzewodywalny i niedbały.</li>
            <li>Potrzebuje stałego kontaktu z ludzmi.</li>
            <li>Jest nieposłuszny względem władzy, źle znosi zwierzchnictwo nad sobą.</li>
          </ul>
          </th>
        </tr>
        </table>
        </div>
		<br> <br>													
		<b> Żółci nie odczuwają potrzeby robienia kariery i zdobywania pieniędzy. Praca idealna dla Żółtego: </b>
        <ul>
		<li>Zawody i stanowsika pracy w wysoką ekspozycją społeczną.</li>
		<li>Stanowiska samodzielne, bez bezpośredniej podległości i nadzoru.</li>
		<li>Praca wymagająca kreatywności i innowacyjnych rozwiązań.</li>
        <li>Stanowiska wymagające częstych kontaktów międzyludzkich.</li>
		</ul>
      
        <b>Zawody odpowiednie dla Żółtego: </b><br>
		Strażak, Agent biura podróży, Organizator wypoczynku, Ratownik, Kosmetyczka, Artysta estradowy,  Konsultant do spraw stosunków międzynarodowych, Przewodnik wycieczek, Artysta cyrkowy, Agent ubezpieczeniowy, Sekretarka, Recepcjonistka, Duchowny, Sprzedawca
   
       <br><br><br><br>
      <div class="zrodlo">
      Opracowano na podstawie: Taylor Hartman, "Kod kolorów. Typy osobowości zaszyfrowane w kolorach.", przekł. Lidia Rafa, Warszawa: Amber 1999 oraz <a href="http://zskesowo.kopi.edu.pl/userfiles/file/beata/kwestionariusz_osobowosciowy_interpretacja_wynikow.pdf">http://zskesowo.kopi.edu.pl</a>
      </div>
       </div><br><br><br>
 
<!--***********************SKRYPTY**********************		-->  
        <script>
            $(document).ready(function(){
               $(window).bind('scroll', function() {
               var wys_nawigacji = $( window ).height() * 0.2;
                     if ($(window).scrollTop() > wys_nawigacji) {
                         $('nav').addClass('nav_stala');
                     }
                     else {
                         $('nav').removeClass('nav_stala');
                     }
                });
            });
        </script>
        <script>
            function rozwin_nawigacje() {
                var element =  document.getElementById('nawigacja');
                if (element.className === "nav") {
                    element.className += " zmienna";
                } else {
                    element.className = "nav";
                }
}
        </script>
    </body> 
</html>