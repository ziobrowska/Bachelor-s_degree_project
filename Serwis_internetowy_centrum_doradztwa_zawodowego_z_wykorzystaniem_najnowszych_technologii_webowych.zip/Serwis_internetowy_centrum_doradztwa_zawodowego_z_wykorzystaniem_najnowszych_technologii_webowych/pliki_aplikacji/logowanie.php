<?php
session_start();

if((!isset($_POST['email'])) || (!isset($_POST['haslo']))){
  header('Location: index.php');
  exit();
}


  require_once "polacz.php";

  $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);
  unset($_SESSION['blad']);

  if($lacze->connect_errno!=0){
    echo "Błąd: ".$lacze->connect_errno;
  }
  else{
    $email = $_POST['email'];
    $haslo = $_POST['haslo'];

    $email = htmlentities($email, ENT_QUOTES, "UTF-8");

    $odpowiedz = @$lacze->query(sprintf("SELECT * FROM uzytkownicy WHERE email_u = '%s'", mysqli_real_escape_string($lacze, $email)));

    if($odpowiedz) {
      $ilu_uzytkownikow = $odpowiedz->num_rows;

      //czy jest uzytkownik taki w bazie
      if( $ilu_uzytkownikow > 0){

        //pobieram cały rekord  
        $rekord = $odpowiedz->fetch_assoc();

        //czy zgadzają sie hasla    
        if(password_verify($haslo, $rekord['haslo'])){

            $_SESSION['zalogowanie'] = true;


          //pobieram podstawowe dane
            $_SESSION['id'] = $rekord['id_uzytkownika'];
            $id = $rekord['id_uzytkownika'];
            $_SESSION['imie'] = $rekord['imie'];
            $_SESSION['nazwisko'] = $rekord['nazwisko'];
            $_SESSION['wiek'] = $rekord['wiek'];
            $_SESSION['plec'] = $rekord['plec'];
            $_SESSION['telefon'] = $rekord['telefon'];
            $_SESSION['adres'] = $rekord['adres'];
          
          if( $_SESSION['wiek'] > 17){
            $pyt = @$lacze->query("SELECT * FROM dorosli WHERE id_uzytkownika = '$id'");

             if($pyt && $pyt->num_rows == 1){
                    $odp = $pyt->fetch_assoc();
                    $opiekun = $odp['czy_opiekun'];
                    $_SESSION['zawod'] = $odp['zawod'];
                    $_SESSION['wyksztalcenie'] = $odp['wyksztalcenie'];
               

                 if($opiekun == 'NIE'){
                   $_SESSION['opiekun'] = 'NIE';
                 }
                 if($opiekun == 'TAK'){
                   $_SESSION['opiekun'] = 'TAK';
                 }

              }else{
                $_SESSION['blad'] = '<span style="color:red"> DOROSŁY ! :(  </span>';
                header('Location: index.php');
              }
              
          }
          if( $_SESSION['wiek'] < 18){
            $pyt2 = @$lacze->query("SELECT * FROM nieletni WHERE id_uzytkownika = '$id'");

             if($pyt2 && $pyt2->num_rows == 1){
                    $odp2 = $pyt2->fetch_assoc();
                    $_SESSION['szkola'] = $odp2['szkola'];
                
              }else{
                $_SESSION['blad'] = '<span style="color:red"> Kwestionariusz 2 ! :(  </span>';
                header('Location: index.php');
              }
              
          }
       
          //pobieram dane odnosnie kwestionariusza
          $zapytanie = @$lacze->query("SELECT * FROM testy WHERE id_uzytkownika = '$id'");

          if($zapytanie) {
          $ilu_uzytkownikow2 = $zapytanie->num_rows;

            //czy ten uzytkownik wykonał kwestionariusz
            if($ilu_uzytkownikow2 == 1){

              $rekord2 = $zapytanie->fetch_assoc();
              $id_testu = $rekord2['id_testu'];
              $_SESSION['czy_kwestionariusz'] = true;

              $zapytanie2 = @$lacze->query("SELECT * FROM wyniki WHERE id_testu = '$id_testu'");

                  if($zapytanie2) {
                      $rekord3 = $zapytanie2->fetch_assoc();
                    if($rekord3['kolor'] == 'BRAK'){
                      $_SESSION['kolor'] = 'MIX';
                    }else{
                      $_SESSION['kolor'] = $rekord3['kolor'];
                    }

                  }else{
                    $_SESSION['blad'] = '<span style="color:red"> Kwestionariusz 2 ! :(  </span>';
                    header('Location: index.php');
                  }

            }else{
              $_SESSION['czy_kwestionariusz'] = false;
            }


          }else{
            $_SESSION['blad'] = '<span style="color:red"> Kwestionariusz 1 ! :(  </span>';
            header('Location: index.php');
          }

          //pobieram dane odnosnie rezerwacji
          $zapytanie3 = @$lacze->query("SELECT * FROM rezerwacje WHERE id_uzytkownika = '$id'");
           
          if($zapytanie3) {
            $ile_rezerwacji = $zapytanie3->num_rows;
                      //czy ten uzytkownik ma juz rezerwację
            if($ile_rezerwacji == 1){
              
              //pobieram info o rezerwacji
              $_SESSION['rezerwacje'] = true;
              $rekord4 = $zapytanie3->fetch_assoc();
              $id_wizyty = $rekord4['id_wizyty'];
              
              //pobieram date rezerwacji
              $data_rezerwacji = strtotime($rekord4['data_r']);
              $data_dzis = strtotime("now");
              
              //sprawdzam, czy moge ją jeszcze usunac            
              if(($data_rezerwacji + (60*60*24*3)) > $data_dzis){
                $_SESSION['czy_usunac_rezerwacje'] = true;
                $_SESSION['id_rezerwacji'] = $rekord4['id_rezerwacji'];
              }else{
                $_SESSION['czy_usunac_rezerwacje'] = false;
              }
          
             // pobieram dane wizyty 
             $zapytanie4 = @$lacze->query("SELECT * FROM wizyty WHERE id_wizyty = '$id_wizyty'");

                  if($zapytanie4) {
                      $rekord5 = $zapytanie4->fetch_assoc();
                      
                      $data_wizyty = strtotime($rekord5['data_w']);
                      $godzina_wizyty = strtotime($rekord5["godzina_w"]);
                    
                      $_SESSION['data_wizyty'] = date('d.m.Y', $data_wizyty);
                      $_SESSION['godzina_wizyty'] = date('H:i', $godzina_wizyty);

                  }else{
                    $_SESSION['blad'] = '<span style="color:red"> Wizyta ! :(  </span>';
                    header('Location: index.php');
                  }

            }else{
              $_SESSION['rezerwacje'] = false;
            }
            
          }else{
              $_SESSION['blad'] = '<span style="color:red"> Rezerwacja 1 ! :(  </span>';
              header('Location: index.php');
          }

            unset($_SESSION['blad']);
            $odpowiedz->close();
            header('Location: login.php');

        }else{
          $_SESSION['blad'] = '<span style="color:red"> Nieprawidłowe hasło! :(  </span>';
          header('Location: index.php');
        }

      }else{
        $_SESSION['blad'] = '<span style="color:red"> Nieprawidłowy login! :(  </span>';
        header('Location: index.php');
      }
    }


  }

?>