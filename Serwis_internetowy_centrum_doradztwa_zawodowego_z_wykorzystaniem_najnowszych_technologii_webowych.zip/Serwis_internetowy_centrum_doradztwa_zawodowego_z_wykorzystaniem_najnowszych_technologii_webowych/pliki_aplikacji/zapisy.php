<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Zapisy na spotkanie | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_login.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
      </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
     <div id="zaloguj_przyciski"> 
<span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 
<!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego 
      </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
   <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php"> Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a id="aktywna" href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
       <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
  <!--***********************START**********************		-->
      <div class="start" id="start">
       
<?php
  if(isset($_SESSION['czy_kwestionariusz']) && ($_SESSION['czy_kwestionariusz'] == true)){      
        
  if(isset($_SESSION['rezerwacje']) && ($_SESSION['rezerwacje'] == false)){
    
    if(isset($_SESSION['usunieto_rezerwacje']) && ($_SESSION['usunieto_rezerwacje'] == true)){
      echo ' <br> <br> <div class="wyroznij2" style="color:red">Rezerwacja została usunięta!</div>';
      unset($_SESSION['usunieto_rezerwacje']);
    }
  
     echo '<div class="naglowek">Umów się na spotkanie z doradcą zawodowym</div>';
    //lacze sie z bazą
    require_once "polacz.php";

      mysqli_report(MYSQLI_REPORT_STRICT);

      try{

        $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
          throw new Exception(mysqli_connect_errno());

        }else{
            $dni = 7;
            $data = date("Y-m-d");
            $wynik = date("Y-m-d",(strtotime($data) + (60*60*24*$dni)));

          $odpowiedz = @$lacze->query("SELECT * FROM wizyty WHERE DATE(data_w) >= '$wynik' AND wizyty.id_wizyty NOT IN (SELECT id_wizyty FROM rezerwacje WHERE id_wizyty IS NOT NULL) order by data_w");


          if(!$odpowiedz) throw new Exception($lacze->error); 

          $ile_wizyt = $odpowiedz->num_rows;

          if($ile_wizyt > 0){
          echo '<div class="responsywna2">'; 
          echo "<table>"; 
          echo'<tr> <th>Data</th> <th>Godzina</th> <th>Doradca</th> <th></th></tr>';
            while($rekord = $odpowiedz->fetch_assoc()) {
                $data = strtotime($rekord["data_w"]);
                $czas = strtotime($rekord["godzina_w"]);
                $data2 = date('d.m.Y', $data);
                $czas2 = date('H:i', $czas);
                echo "<tr>"; 
                echo "<td>".$data2."r.</td>";
                echo '<td>'.$czas2.'</td>';
                echo '<td>'.$rekord["dane_doradcy"].'</td>';
                echo "<td> <a id=\"zrezygnuj2\" href=\"rezerwacja.php?id_wizyty={$rekord['id_wizyty']}&amp;data_wizyty={$data2}&amp;godzina_wizyty={$czas2}\">ZAREZERWUJ TĄ WIZYTĘ </a> 
               </td>"; 
                echo "</tr>"; 
            } 
            echo "</table>";
            echo "</div>";
         }
          $lacze->close();
        }

          }catch(Exception $ex){
          echo '<span style="color:red"> Błąd serwera, proszę spróbować później! </span>';
          }
    
    
    }else{
     if(!isset($_SESSION['dokonano_rezerwacji'])){
      echo ' <br> <br> <br><div class="wyroznij2"> Posiadasz zarezerwowaną konsultację: </div>';
     }
    
    
     if(isset($_SESSION['dokonano_rezerwacji']) && ($_SESSION['dokonano_rezerwacji'] == true)){
      echo ' <br> <br> <br><div class="wyroznij2" style="color:green"> Pomyślnie zarezerwowano wybraną wizytę! </div>';
      unset($_SESSION['dokonano_rezerwacji']);
    }
    
    
    echo '<div class="naglowek2">Doradca zawodowy czeka na Ciebie w naszym Centrum <b> '.$_SESSION['data_wizyty'].' r. </b> o godzinie <b>'.$_SESSION['godzina_wizyty'].'</b>.</div>';
    
    //lacze sie z bazą
    require_once "polacz.php";
      mysqli_report(MYSQLI_REPORT_STRICT);

      try{

        $lacze = @new mysqli($serwer, $db_uzytkownik, $db_haslo, $db_nazwa);

        if($lacze->connect_errno!=0){
          throw new Exception(mysqli_connect_errno());

        }else{
          //pobieram dane odnosnie oplaty rezerwacji
          $id = $_SESSION['id'];
          $pytanie = @$lacze->query("SELECT * FROM oplaty WHERE id_uzytkownika = '$id'");

          if(!$pytanie) throw new Exception($lacze->error); 

          //czy ten uzytkownik ma juz rezerwację
          if($pytanie->num_rows == 1){
            $oplaty = $pytanie->fetch_assoc();
            $stan_oplaty = $oplaty['czy_op_rezerwacja'];

            if($stan_oplaty == 'TAK'){
              $_SESSION['oplata'] = true;
            }
            if($stan_oplaty == 'NIE'){
              $_SESSION['oplata'] = false;
            }
          }
                     
          $lacze->close();
         }

       }catch(Exception $ex){
          echo '<span style="color:red"> Błąd serwera, proszę sprobowac później! </span>';
      }

    
    if((isset($_SESSION['oplata'])) && ($_SESSION['oplata'] == true)){
  echo '<br> <div class="wyroznij2" style="color:green">Konsultacja została opłacona!</div>';
    
    }
    if((isset($_SESSION['oplata'])) && ($_SESSION['oplata'] == false)){
  echo ' <br> <div class="wyroznij2" style="color:red">Konslutacja nie została opłacona!</div>';
    
    }
    
    if((isset($_SESSION['czy_usunac_rezerwacje'])) && ($_SESSION['czy_usunac_rezerwacje'] == true) && (isset($_SESSION['oplata'])) && ($_SESSION['oplata'] == false)){
      
      $id_rezerwacji = $_SESSION['id_rezerwacji'];
     
      echo "<br> <div class=\"rezygnacja\"> <a href=\"rezerwacja.php?id_rezerwacji={$id_rezerwacji}\">Zrezygnuj z tej wizyty</a>";
    }
}
}else{
    echo '<br> <br> <div class="wyroznij2" style="color:red" >Przed dokonaniem zapisu na spotkanie musisz wypełnić kwestionariusz osobowości!</div>';
  }
    ?>
    
      </div>
  <br> <br> <br> <br>
<!--***********************SKRYPTY**********************		-->  
      <script>
         $(document).ready(function(){
             $(window).bind('scroll', function() {
             var wys_nawigacji = $( window ).height() * 0.2;
                   if ($(window).scrollTop() > wys_nawigacji) {
                       $('nav').addClass('nav_stala');
                   }
                   else {
                       $('nav').removeClass('nav_stala');
                   }
              });
          });
      </script>
      <script>
        function rozwin_nawigacje() {
            var element =  document.getElementById('nawigacja');
            if (element.className === "nav") {
                element.className += " zmienna";
            } else {
                element.className = "nav";
            }
        }
    </script>
  </body>  
</html>