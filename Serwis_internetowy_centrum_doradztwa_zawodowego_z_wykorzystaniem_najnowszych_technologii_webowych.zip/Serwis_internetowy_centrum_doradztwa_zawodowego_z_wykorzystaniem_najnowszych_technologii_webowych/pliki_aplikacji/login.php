<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title> Witaj w serwisie | Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
      <link href="arkusz_stylu_login.css" rel="stylesheet" type="text/css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
       </head>
    <body>
<!--***********************Przyciski_góra**********************		-->
      <div id="zaloguj_przyciski"> 
      <span id="schowaj">
<?php
    echo  "Jesteś zalogowany jako ".$_SESSION['imie']." ".$_SESSION['nazwisko'];
?>
      &nbsp;|&nbsp;</span><button class="wyloguj" id="wyloguj"><a href="wylogowanie.php">Wyloguj&nbsp;</a></button>
      </div>
 <!--***********************Tytul**********************		-->
    <header>
      <div id="nazwa"> Serwis Centrum Doradztwa Zawodowego </div>
    </header>
<!--***********************NAWIGACJA**********************		-->
   <nav>
    <div id="nawigacja" class="nav">
      <a href="login.php">Start</a>
      <a href="dane.php">Moje dane </a>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php">Kwestionariusz osobowości</a>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php">Kwestionariusz osobowości</a>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php">Kwestionariusz osobowości</a>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php">Kwestionariusz osobowości</a>';
      }
      ?>   
      <a href="zapisy.php">Zapisy online</a>
      <a href="historia.php">Archiwum spotkań</a>
      <a href="oferta.php">Oferta Centrum</a>
      <a href="kontakt.php">Kontakt</a>
      <a href="javascript:void(0);" class="znaczek" onclick="rozwin_nawigacje()">&#9776;</a>
      </div>
    </nav>
             
  <!--***********************START**********************		-->
  <div class="start" id="start">
<?php
   echo '<div class="naglowek"> Witaj, '.$_SESSION['imie']." ".$_SESSION['nazwisko']."! </div> <br>";  
?> 
    <div class="powitanie">
      <p class="wyroznij2" >Serwis internetowy Centrum Doradztwa Zawodowego został stworzony z myślą o komforcie naszych klientów.</p> 
       
    <div class="wyroznij2">Dziękujemy, że tu jesteś!</div><br>
      Tutaj możesz:<br><br>
      
      <a href="oferta.php">-> zapoznać się z ofertą naszego centrum</a><br>
      <a href="dane.php">-> zrządzać swoim kontem osobistym </a><br>
      <?php
       if($_SESSION['czy_kwestionariusz'] == true){
        if($_SESSION['kolor'] == 'CZERWONY'){
          echo '<a href="typ_a.php"> -> uzupełnić kwestionariusz osobowościowy</a><br>';
        }
        if($_SESSION['kolor'] == 'NIEBIESKI'){
          echo '<a href="typ_b.php"> -> uzupełnić kwestionariusz osobowościowy</a><br>';
        }
        if($_SESSION['kolor'] == 'BIALY'){
          echo '<a href="typ_c.php"> -> uzupełnić kwestionariusz osobowościowy</a><br>';
        }
        if($_SESSION['kolor'] == 'ZOLTY'){
          echo '<a href="typ_d.php"> -> uzupełnić kwestionariusz osobowościowy</a><br>';
        }
         if($_SESSION['kolor'] == 'MIX'){
          echo '<a href="typ_mix.php"> -> uzupełnić kwestionariusz osobowościowy</a><br>';
        }
      }
      if($_SESSION['czy_kwestionariusz'] == false){
         echo '<a href="kwestonariusz.php"> -> uzupełnić kwestionariusz osobowościowy<br></a>';
      }
      ?>   
      <a href="zapisy.php">-> umówić się na spotkanie z doradcą zawodowym </a><br>
      <a href="zapisy.php">-> sprawdzić stan opłaty Twojej rejestracji</a><br>
      <a href="historia.php">-> podejrzeć historię odbytych już spotkań</a><br>
   
    </div>
   <br><br><br>
    </div>
<!--***********************SKRYPTY**********************		-->     
  <script>
   $(document).ready(function(){
	   $(window).bind('scroll', function() {
	   var wys_nawigacji = $( window ).height() * 0.2;
			 if ($(window).scrollTop() > wys_nawigacji) {
				 $('nav').addClass('nav_stala');
			 }
			 else {
				 $('nav').removeClass('nav_stala');
			 }
		});
	});
  </script>
       <script>
    function rozwin_nawigacje() {
        var element =  document.getElementById('nawigacja');
        if (element.className === "nav") {
            element.className += " zmienna";
        } else {
            element.className = "nav";
        }
    }
</script>

    </body>
</html>