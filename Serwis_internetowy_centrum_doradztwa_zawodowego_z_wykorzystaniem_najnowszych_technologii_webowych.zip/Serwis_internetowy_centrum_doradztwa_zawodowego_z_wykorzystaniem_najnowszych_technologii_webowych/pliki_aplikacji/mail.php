<?php

session_start();

if(!isset($_SESSION['zalogowanie'])){
  header('Location: index.php');
  exit();
}

if(isset($_POST['temat'])){
  	$adresat = 'joasia.ziobrowska@wp.pl'; 	
	$temat = $_POST['temat'];
	$tresc = $_POST['tresc'];
   
	$naglowek = 'From: '.$_SESSION['imie']." ".$_SESSION['nazwisko']." \nContent-Type:".
			' text/plain;charset="iso-8859-2"'.
			"\nContent-Transfer-Encoding: 8bit";
    
  $wyslij = mail($adresat, $temat, $tresc, $naglowek);
 
	if ($wyslij){
      $_SESSION['mail'] = true;
      unset($_POST['temat']);
      unset($_POST['tresc']);
    }
  
	else{ 
	 $_SESSION['mail'] = false;
      unset($_POST['temat']);
      unset($_POST['tresc']);
    }
  
  header('Location: kontakt.php');
}else {
  header('Location: kontakt.php');
  exit();
}

?>