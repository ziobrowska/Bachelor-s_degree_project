<?php
session_start();

if((isset($_SESSION['zalogowanie'])) && ($_SESSION['zalogowanie']==true)){
  header('Location: login.php');
  exit();
}


// kasuje zmienne zapamietane  w formularzu
if(isset($_SESSION['zapamietaj_imie'])){
   unset($_SESSION['zapamietaj_imie']);
}
     
if(isset($_SESSION['zapamietaj_nazwisko'])){
   unset($_SESSION['zapamietaj_nazwisko']);
}
  
if(isset($_SESSION['zapamietaj_wiek'])){
   unset( $_SESSION['zapamietaj_wiek'] );
}
    
if(isset($_SESSION['zapamietaj_haslo1'])){
   unset($_SESSION['zapamietaj_haslo1']);
}
    
if(isset($_SESSION['zapamietaj_haslo2'])){
   unset($_SESSION['zapamietaj_haslo2']);
}
    
if(isset($_SESSION['zapamietaj_email'])){
   unset($_SESSION['zapamietaj_email']);
}
    
if(isset($_SESSION['zapamietaj_email_d'])){
   unset($_SESSION['zapamietaj_email_d']);
}
    
if(isset($_SESSION['zapamietaj_regulamin'])){
    unset($_SESSION['zapamietaj_regulamin']);
}
   
if(isset( $_SESSION['zapamietaj_mezczyzna'])){
    unset($_SESSION['zapamietaj_mezczyzna']);
}
  
if(isset($_SESSION['zapamietaj_kobieta'])){
    unset($_SESSION['zapamietaj_kobieta']);
}

//usuwam zapamiętane błedy formularza z danej sesji 

if (isset($_SESSION['blad_email'])){
    unset($_SESSION['blad_email']);
}

if (isset($_SESSION['blad_plec'])){
    unset($_SESSION['blad_plec']);
}
if (isset($_SESSION['blad_regulamin'])){
    unset($_SESSION['blad_regulamin']);
}

if (isset($_SESSION['blad_boot'])){
    unset($_SESSION['blad_boot']);
}

if (isset($_SESSION['blad_email_d'])){
    unset($_SESSION['blad_email_d']);
}

if (isset($_SESSION['blad_wiek'])){
    unset($_SESSION['blad_wiek']);
}

if(isset($_SESSION['blad_nazwisko'])){
    unset($_SESSION['blad_nazwisko']);
}

if (isset($_SESSION['blad_imie'])){
    unset($_SESSION['blad_imie']);
}

 if (isset($_SESSION['blad_haslo'])){
    unset($_SESSION['blad_haslo']);
}

?>


<!DOCTYPE html>
<html lang="pl-PL">
	<head>
        <meta charset="UTF-8">
        <title>Zaloguj się| Centrum Doradztwa Zawodowego</title>
		
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta name="description" content="Centrum Doradztwa Zawodowego. Z nami dowiesz sie, jaki zawód jest Ci pisany!">
		<meta name="author" content="Joanna Ziobrowska">
 
<!--***********************CSSY**********************		-->
        <link rel="stylesheet" type="text/css" href="arkusz_stylu_indeks.css">
        
<!--***********************CZCIONKI**********************		-->
      <link href='http://fonts.googleapis.com/css?family=Capriola&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
 		
<!--***********************SKRYPTY**********************		-->       
      <script type="text/javascript" src="http://code.jquery.com/jquery-1.8.3.min.js"></script>
          
    </head>
    <body> <div class="loguj2" id="loguj"> 
      <form class="formularz_logowania" action="logowanie.php" method="post"> 
    
        <div id="naglowek"> Logowanie do serwisu Centrum Doradztwa Zawodowego</div>
        <div id="zamknij2" class="zamknij" title="Powrót do strony głównej">&times;</div> 
      <?php
        if(isset($_SESSION['udana_rejestracja'])){
        if($_SESSION['udana_rejestracja'] == true){
          echo '<div style="color:red"> Dziękujemy za rejestrację w naszym serwisie!<br> Możesz już zalogować się na swoje konto.</div>';
          unset($_SESSION['udana_rejestracja']);
        }
        }
        ?>
        <div id='polecenie' > Podaj adres e-mail oraz hasło </div>
        <div id='formularz'> 
      
          <label>E-mail:</label>
          <input type="text" placeholder="np. jankowalski@gmail.com" name="email" required/>
          <br>
          <label>Hasło:</label>
          <input type="password" placeholder="Haslo" name="haslo" required/>
          <br>
            <div id="ikony_pod">
              <input type="submit" value="Zaloguj">
              <br>
            </div>
          <span id='do_rejestracji'> Nie masz konta? Zarejestruj się! </span>
        </div>
      </form>
      </div> 
  </body>
  <script>
      $( "#zamknij2" ).on('click', function() {
                 window.location.href = "index.php";
      });
      $( "#do_rejestracji" ).on('click', function() {
            window.location.href = "rejestracja.php"
      });
    </script>
</html>