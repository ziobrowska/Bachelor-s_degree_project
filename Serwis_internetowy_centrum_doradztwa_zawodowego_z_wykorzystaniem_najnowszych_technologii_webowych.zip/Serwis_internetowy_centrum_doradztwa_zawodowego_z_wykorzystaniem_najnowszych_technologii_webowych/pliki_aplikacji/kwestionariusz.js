$(document).ready(function(){
            $( "#rozpocznij_kwest" ).on('click', function() {
                $( "#kwestionariusz_opis").hide();
                $( "#rozpocznij_kwest").hide(); 
                $( ".kwestionariusz_slajdy").show();
                (function(){
                    
            const pytania = [
            {
            pytanie: "Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Nie zmieniam poglądów",
                b: "Jestem opiekuńczy",
                c: "Jestem pomysłowy",
                d: "Lubię rozrywki"
                },
            },
            {            
            pytanie: "Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Lubię mieć władzę",
                b: "Jestem perfekcjonistą",
                c: "Jestem niezdecydowany",
                d: "Jestem egocentryczny"
                },
            },
            {
            pytanie: "Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem dominujący",
                b: "Jestem życzliwy",
                c: "Jestem tolerancyjny",
                d: "Jestem entuzjastyczny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem samodzielny",
                b: "Jestem podejrzliwy",
                c: "Jestem niepewny siebie",
                d: "Jestem naiwny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Szybko podejmuję decyzję",
                b: "Jestem lojalny",
                c: "Jestem zadowolony",
                d: "Jestem wesoły"
                },
           
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem arogancki",
                b: "Często się martwię",
                c: "Jestem uparty",
                d: "Jestem niestały w uczuciach"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem asertywny",
                b: "Można na mnie polegać",
                c: "Jestem miły",
                d: "Jestem towarzyski"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem apodyktyczny",
                b: "Jestem samokrytyczny",
                c: "Jestem niechętny do działania",
                d: "Lubię prowokować"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Lubię działać",
                b: "Mam naturę analityka",
                c: "Jestem wyrozumiały",
                d: "Jestem beztroski"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem krytyczny",
                b: "Jestem nadwrażliwy",
                c: "Jestem nieśmiały",
                d: "Bywam trudny do zniesienia"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem stanowczy",
                b: "Jestem pedantyczny",
                c: "Uważnie słucham",
                d: "Lubię przyjęcia"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem wymagający",
                b: "Nie wybaczam",
                c: "Brak mi motywacji",
                d: "Jestem próżny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem odpowiedzialny",
                b: "Jestem idealistą",
                c: "Jestem delikatny",
                d: "Jestem szczęśliwy"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem niecierpliwy",
                b:"Miewam zmienne nastroje",
                c:"Jestem bierny",
                d:"Jestem impulsywny",
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Mam silną wolę",
                b:"Szanuję innych",
                c:"Jestem cierpliwy",
                d:"Lubię żartować"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Lubię dyskutować",
                b:"Jestem marzycielem",
                c:"Brak mi celu w życiu",
                d:"Przerywam innym"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem niezależny",
                b:"Można mi zaufać",
                c:"Jestem zrównoważony",
                d:"Jestem ufny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem agresywny",
                b:"Często wpadam w depresję",
                c:"Bywam wieloznaczny",
                d:"Jestem zapominalski"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem władczy",
                b:"Jestem rozważny",
                c:"Jestem taktowny",
                d:"Jestem optymistą"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem mało wrażliwy",
                b:"Często osądzam ludzi",
                c:"Jestem nudny",
                d:"Jestem niezdyscyplinowany"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi:{
                a:"Myślę logicznie",
                b:"Ulegam emocjom",
                c:"Jestem ustępliwy",
                d:"Jestem lubiany"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: { 
                a:"Mam zawsze rację",
                b:"Często mam poczucie winy",
                c:"Jestem mało entuzjastyczny",
                d:"Jestem mało zaangażowany"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem pragmatykiem",
                b:"Jestem kulturalny",
                c:"Jestem otwarty",
                d:"Jestem spontaniczny"
                },
            },
            {   
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi:{
                a: "Jestem bezlitosny",
                b: "Jestem troskliwy",
                c: "Nie emocjonuję się tym, co robię",
                d: "Lubię się popisywać"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Skupiam się na osiąganiu celu",
                b: "Jestem szczery",
                c: "Jestem dyplomatą",
                d: "Jestem energiczny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a: "Jestem nietaktowny",
                b: "Jestem wybredny",
                c: "Jestem leniwy",
                d: "Jestem hałaśliwy",
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi:{
                a:"Jestem wyrachowany",
                b:"Jestem obłudny",
                c:"Jestem zakompleksiony",
                d:"Jestem niezorganizowany"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem pewny siebie",
                b:"Jestem zdyscyplinowany",
                c:"Jestem sympatyczny",
                d:"Jestem charyzmatyczny"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Onieśmielam innych",
                b:"Jestem ostrożny",
                c:"Jestem nieproduktywny",
                d:"Unikam konfrontacji"
                },
            },
            {
            pytanie:"Zaznacz stwierdzenie, które najlepiej do Ciebie pasuje. Wybierz tylko jedną odpowiedź.",
            odpowiedzi: {
                a:"Jestem bezpośredni",
                b:"Jestem twórczy",
                c:"Łatwo się przystosowuję",
                d:"Żyję na pokaz"
                },
            },
            {
            pytanie:"Gdybym starał się o pracę, prawdopodobnie zatrudniono by mnie, bo jestem:",
            odpowiedzi: {
                a:" Bezpośredni i mocno angażuję się w to, co robię.",
                b:" Rozważny, dokładny i można na mnie polegać.",
                c:" Cierpliwy, taktowny i łatwo adaptuję się w nowych sytuacjach.",
                d:" Towarzyski, nonszalancki i pełen zapału."
                },
            },
            {
            pytanie:" Gdy w związku intymnym czuję się zagrożony przez partnera, wtedy:",
            odpowiedzi:{
                a:" Odczuwam gniew i reaguję agresywnie.",
                b:" Płaczę, czuję się urażony, planuję zemstę.",
                c:" Jestem spokojny, wycofuję się, często powstrzymuję złość, a potem wybucham z powodu byle drobiazgu.",
                d:" Dystansuję się i unikam dalszych konfliktów."
                },
            },
            {
            pytanie:" Życie ma sens tylko wtedy, gdy:",
            odpowiedzi: {
                a:" Dążę do osiągnięcia wyznaczonego celu i jestem aktywny.",
                b:" Przebywam z ludźmi i mam określony cel.",
                c:" Jest wolne od stresów i napięć.",
                d:" Mogę się nim cieszyć i nie mam powodów do zmartwień."
                },
            },
            {
            pytanie:" Jako dziecko byłem:",
            odpowiedzi:{
                a:" Uparty, błyskotliwy i/lub agresywny.",
                b:" Grzeczny, troskliwy i/lub miałem skłonność do depresji.",
                c:" Cichy, niewymagający i/lub nieśmiały.",
                d:" Gadatliwy, zadowolony i/lub chętny do zabawy."
                },
            },
            {
            pytanie:" Jako osoba dorosła jestem:",
            odpowiedzi:{
                a:" Uparty, stanowczy i/lub apodyktywczny.",
                b:" Odpowiedzialny, uczciwy i/lub pamiętliwy.",
                c:" Tolerancyjny, zadowolony i/lub brakuje mi motywacji.",
                d:" Charyzmatyczny, pozytywnie nastawiony do życia i/lub bywam nieznośny."
                },
            },
            {
            pytanie:" Jako rodzic jestem/będę:",
            odpowiedzi:{
                a:" Wymagający, porywczy i/lub bezkompromisowy.",
                b:" Troskliwy, wrażliwy i/lub krytyczny.",
                c:" Skłonny do ustępstw, na wszystko pozwalam i/lub czuję się przytłoczony.",
                d:" Chętny do zabaw, niesystematyczny i/lub nieodpowiedzialny."
                },
            },
            {
            pytanie:" Podczas sprzeczek z przyjaciółmi najczęściej:",
            odpowiedzi:{
                a:" Upieram się przy swoim zdaniu.",
                b:" Myślę o zasadach jakie wyznają i zastanawiam się nad tym, co czują.",
                c:" Jestem zacięty, czuję się nieswojo i/lub jestem zmieszany.",
                d:" Zachowuję się głośno, czuję się nieswojo i/lub idę na kompromis."
                },
            },
            {
            pytanie:" Gdy przyjaciele mają kłopoty jestem:",
            odpowiedzi:{
                a:" Opiekuńczy, zaradny i łatwo znajduję rozwiązanie problemu.",
                b:" Szczerze zainteresowany, współczuję i jestem lojalny – niezależnie od problemu.",
                c:" Cierpliwy, potrafię podnieść na duchu i chętnie słucham.",
                d:" Powściągliwy w wydawaniu opinii, nastawiony optymistycznie i potrafię rozładować napiętą sytuację."
                },
            },
            {
            pytanie:" Podejmując decyzję jestem:",
            odpowiedzi:{
                a:" Asertywny, precyzyjny i logiczny.",
                b:" Rozważny, dokładny i ostrożny.",
                c:" Niezdecydowany, nieśmiały i zniechęcony.",
                d:" Impulsywny, niekonsekwentny i mało zaangażowany."
                },
            },
            {
            pytanie:" W obliczu niepowodzeń:",
            odpowiedzi:{
                a:" W duchu jestem samokrytyczny, ale głośno bronię swoich racji i nie przyznaję się do winy.",
                b:" Mam poczucie winy, jestem samokrytyczny, mam skłonność do depresji i w nią wpadam.",
                c:" W duchu odczuwam niepewność i strach.",
                d:" Jestem zażenowany i nerwowy, staram się uciec od problemu."
                },
            },
            {
            pytanie:" Gdy ktoś mnie urazi:",
            odpowiedzi:{
                a:" Jestem zdenerwowany i w duchu planuję szybki rewanż.",
                b:" Czuję się głęboko dotknięty i w zasadzie nigdy całkowicie nie wybaczam. Zemsta to za     mało.",
                c:" W głębi duszy czuję się zraniony i szukam odwetu i/lub staram się unikać tej osoby.",
                d:" Unikam konfrontacji, uznaję sytuację za niewartą zachodu i/lub szukam pomocy u przyjaciół."
                },
            },
            {
            pytanie:" Praca to:",
            odpowiedzi:{
                a:" Najlepszy sposób na życie",
                b:" Czynność, którą należy wykonywać najlepiej jak się potrafi, lub nie wykonywać wcale. Moje motto to: najpierw obowiązek, potem przyjemność.",
                c:"Działalność pozytywna, jeśli sprawia mi przyjemność i nie mam obowiązku doprowadzania jej do końca.",
                d:"Zło konieczne, zdecydowanie mniej przyjemne od rozrywki."
                },
            },
            {
            pytanie:" W sytuacjach towarzyskich ludzie najczęściej:",
            odpowiedzi: {
                a:" Boją się mnie.",
                b:" Podziwiają mnie.",
                c:" Zajmują się mną.",
                d:" Zazdroszczą mi."
                },
            },
            {
            pytanie:" W związkach intymnych najbardziej zależy mi, by być:",
            odpowiedzi: {
                a:" Aprobowanym i postępować słusznie.",
                b:" Rozumianym, docenianym i bliskim drugiej osobie.",
                c:" Szanowanym, tolerancyjnym i zgodnym.",
                d:" Docenianym, wolnym i dobrze się bawić."
                },
            },
            {
            pytanie:" By czuć się dobrze, potrzebuję:",
            odpowiedzi: {
                a:" Przywództwa, przygód, działania.",
                b:" Bezpieczeństwa, pracy twórczej, celu.",
                c:" Akceptacji i bezpieczeństwa.",
                d:" Rozrywki, pracy sprawiającej przyjemność i towarzystwa innych ludzi."
                },
            }
                ];
                   
        function wyswietl_Kwest(){
           const do_wyswietlenia = [];

            pytania.forEach((aktualne_Pytanie, numer_Pytania) => {
            const odpowiedzi = [];
            for(litera in aktualne_Pytanie.odpowiedzi){
                odpowiedzi.push(
            `<label>
            <input type="radio" name="pytanie${numer_Pytania}" value="${litera}">
            ${litera} :
            ${aktualne_Pytanie.odpowiedzi[litera]}
          </label>`
                );
            } 
            do_wyswietlenia.push(
            `<div class="slajdy">
            <div class="numer"> ${ 'Pytanie ' + (numer_Pytania + 1) + '/' + pytania.length} </div>
            <div class="pytanie"> ${aktualne_Pytanie.pytanie} <br><br></div>
            <div class="odpowiedzi"> ${odpowiedzi.join(' ')} </div>
            </div>`
            );
            });
                        
        zawart_Kwest.innerHTML = do_wyswietlenia.join(' ');
        }
      
        function pokaz_Wyniki(){ 
            const zawart_Odp = zawart_Kwest.querySelectorAll('.odpowiedzi');
            let numA = 0;
            let numB = 0;
            let numC = 0;
            let numD = 0;
            let flag = 0;

            pytania.forEach((aktualne_Pytanie, numer_Pytania) => {

            const zawart_Odp_pytanie = zawart_Odp[numer_Pytania];
            const selector = 'input[name=pytanie'+numer_Pytania+']:checked';
            const odpowiedz = (zawart_Odp_pytanie.querySelector(selector) || {}).value;
                if (odpowiedz !== undefined){
                    if(odpowiedz === "a"){
                        numA++;
                        
                    }
                    else if(odpowiedz === "b"){
                        numB++;
                        
                    }  
                    else if(odpowiedz === "c"){
                        numC++;
                       
                    }
                    else if(odpowiedz === "d"){
                        numD++;
                    }
                    }
                    else{
                    flag++;
                    }
                    });
    
      var max = Math.max(numA, numB, numC, numD);       
        if (flag === 0){
            if((max === numA) && (numA !== numB) && (numA !== numC) && (numA !== numD)){
            window.location.href = "typ_a.php";
            }
            else if((max === numB) && (numB !== numA) && (numB !== numC) && (numB !== numD)){
            window.location.href = "typ_b.php";
            }
            else if((max === numC) && (numC !== numA) && (numC !== numB) && (numC !== numD)){
            window.location.href = "typ_c.php";
            }
            else if((max === numD) && (numD !== numA) && (numD !== numB) && (numD !== numC)){
            window.location.href = "typ_d.php";
            }
            else{
            window.location.href = "typ_mix.php";
            }
        }
       else {
         alert('Niektóre pytania pozostały bez odpowiedzi!');
            }
        }
                    
        function pokaz_slajd(n) {
            slajdy[aktualny_slajd].classList.remove("aktywny_slajd");
            slajdy[n].classList.add("aktywny_slajd");
            aktualny_slajd = n;
    
            if (aktualny_slajd === 0) {
                przycisk_poprzedni.style.display = "none";
            } else {
                przycisk_poprzedni.style.display = "inline-block";
            }

            if (aktualny_slajd === slajdy.length - 1) {
                przycisk_nastepny.style.display = "none";
                przycisk_Zapisz.style.display = "inline-block";
            } else {
                przycisk_nastepny.style.display = "inline-block";
                przycisk_Zapisz.style.display = "none";
            }
        }
       
        function pokaz_nastepny_slajd() {
            pokaz_slajd(aktualny_slajd + 1);
        }

        function pokaz_poprzedni_slajd() {
            pokaz_slajd(aktualny_slajd - 1);
        } 

        const zawart_Kwest = document.getElementById('zawartosc_kwestionariusza');   
        const wyniki = document.getElementById('wyniki');
        const przycisk_Zapisz = document.getElementById('zapisz_odp');
            
           
        wyswietl_Kwest();
                   
        const przycisk_poprzedni = document.getElementById("poprzednie_pytanie");
        const przycisk_nastepny = document.getElementById("nastepne_pytanie");
        const slajdy = document.querySelectorAll(".slajdy");
        let aktualny_slajd = 0;

        pokaz_slajd(0);
                   
        przycisk_Zapisz.addEventListener('click', pokaz_Wyniki);
        przycisk_poprzedni.addEventListener("click", pokaz_poprzedni_slajd);
        przycisk_nastepny.addEventListener("click", pokaz_nastepny_slajd);
        })();
        }); 
    }); 