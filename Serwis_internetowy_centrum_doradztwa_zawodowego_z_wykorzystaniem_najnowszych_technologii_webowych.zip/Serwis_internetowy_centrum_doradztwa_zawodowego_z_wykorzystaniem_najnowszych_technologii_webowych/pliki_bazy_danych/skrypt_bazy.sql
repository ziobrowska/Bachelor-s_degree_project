-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema centrum_doradztwa
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema centrum_doradztwa
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `centrum_doradztwa` DEFAULT CHARACTER SET utf8 ;
USE `centrum_doradztwa` ;

-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`ceny`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`ceny` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`ceny` (
  `id_ceny` INT(11) NOT NULL AUTO_INCREMENT,
  `kwota` INT(11) NOT NULL,
  `opis` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id_ceny`),
  UNIQUE INDEX `id_ceny_UNIQUE` (`id_ceny` ASC),
  INDEX `kwota_i` (`kwota` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`doradcy`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`doradcy` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`doradcy` (
  `id_doradcy` INT(11) NOT NULL AUTO_INCREMENT,
  `email_d` VARCHAR(45) NOT NULL,
  `imie` VARCHAR(45) NOT NULL,
  `nazwisko` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id_doradcy`),
  UNIQUE INDEX `email_d_UNIQUE` (`email_d` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 23
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`uzytkownicy`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`uzytkownicy` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`uzytkownicy` (
  `id_uzytkownika` INT(11) NOT NULL AUTO_INCREMENT,
  `imie` VARCHAR(45) NOT NULL,
  `nazwisko` VARCHAR(45) NOT NULL,
  `plec` ENUM('K', 'M') NOT NULL,
  `wiek` TINYINT(4) NOT NULL,
  `email_u` VARCHAR(45) NOT NULL,
  `haslo` VARCHAR(65) NOT NULL,
  `dane_d` VARCHAR(45) NULL DEFAULT 'BRAK',
  `email_u_d` VARCHAR(45) NULL DEFAULT 'BRAK',
  `telefon` VARCHAR(45) NULL DEFAULT 'BRAK',
  `adres` VARCHAR(80) NULL DEFAULT 'BRAK',
  PRIMARY KEY (`id_uzytkownika`),
  UNIQUE INDEX `emali_u_UNIQUE` (`email_u` ASC),
  UNIQUE INDEX `id_uzytkownika_UNIQUE` (`id_uzytkownika` ASC))
ENGINE = InnoDB
AUTO_INCREMENT = 53
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`dorosli`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`dorosli` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`dorosli` (
  `id_doroslego` INT(11) NOT NULL AUTO_INCREMENT,
  `id_uzytkownika` INT(11) NOT NULL,
  `zawod` VARCHAR(45) NULL DEFAULT NULL,
  `wyksztalcenie` VARCHAR(45) NULL DEFAULT NULL,
  `czy_opiekun` ENUM('NIE', 'TAK') NULL DEFAULT 'NIE',
  PRIMARY KEY (`id_doroslego`, `id_uzytkownika`),
  UNIQUE INDEX `id_doroslego_UNIQUE` (`id_doroslego` ASC),
  UNIQUE INDEX `id_uzytkownika_UNIQUE` (`id_uzytkownika` ASC),
  CONSTRAINT `FK1_d`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`historia`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`historia` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`historia` (
  `kg_historia` INT(11) NOT NULL AUTO_INCREMENT,
  `id_uzytkownika` INT(11) NOT NULL,
  `id_wizyty` INT(11) NOT NULL,
  `id_doradcy` INT(11) NOT NULL,
  `dane_doradcy` VARCHAR(65) NOT NULL,
  `data` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`kg_historia`),
  INDEX `FK_h_idx` (`id_uzytkownika` ASC),
  CONSTRAINT `FK_h`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`nieletni`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`nieletni` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`nieletni` (
  `id_uzytkownika` INT(11) NOT NULL,
  `id_uzytkownika_d` INT(11) NOT NULL,
  `szkola` VARCHAR(45) NULL DEFAULT NULL,
  PRIMARY KEY (`id_uzytkownika`),
  UNIQUE INDEX `id_uzytkownika_UNIQUE` (`id_uzytkownika` ASC),
  INDEX `FK2_n_idx` (`id_uzytkownika_d` ASC),
  CONSTRAINT `FK1_n`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION,
  CONSTRAINT `FK2_n`
    FOREIGN KEY (`id_uzytkownika_d`)
    REFERENCES `centrum_doradztwa`.`dorosli` (`id_doroslego`)
    ON DELETE CASCADE
    ON UPDATE NO ACTION)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`oplaty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`oplaty` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`oplaty` (
  `id_uzytkownika` INT(11) NOT NULL,
  `czy_op_test` ENUM('NIE', 'TAK') NOT NULL,
  `czy_op_rezerwacja` ENUM('NIE', 'TAK', 'BRAK') NOT NULL,
  PRIMARY KEY (`id_uzytkownika`),
  CONSTRAINT `FK1_o`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`wizyty`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`wizyty` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`wizyty` (
  `id_wizyty` INT(11) NOT NULL AUTO_INCREMENT,
  `id_doradcy` INT(11) NOT NULL,
  `dane_doradcy` VARCHAR(65) NOT NULL,
  `godzina_w` TIME NOT NULL,
  `dzien_w` TINYINT(15) NOT NULL,
  `miesiac_w` TINYINT(15) NOT NULL,
  `rok_w` INT(11) NOT NULL,
  `data_w` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`id_wizyty`),
  INDEX `FK1_idx` (`id_doradcy` ASC),
  CONSTRAINT `FK1_w`
    FOREIGN KEY (`id_doradcy`)
    REFERENCES `centrum_doradztwa`.`doradcy` (`id_doradcy`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 29
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`rezerwacje`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`rezerwacje` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`rezerwacje` (
  `id_rezerwacji` INT(11) NOT NULL AUTO_INCREMENT,
  `id_wizyty` INT(11) NOT NULL,
  `id_uzytkownika` INT(11) NOT NULL,
  `cena_r` INT(11) NOT NULL,
  `data_r` DATETIME NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_rezerwacji`),
  INDEX `FK2_rez_idx` (`id_uzytkownika` ASC),
  INDEX `FK3_rez_idx` (`cena_r` ASC),
  UNIQUE INDEX `id_rezerwacji_UNIQUE` (`id_rezerwacji` ASC),
  CONSTRAINT `FK1_rez`
    FOREIGN KEY (`id_wizyty`)
    REFERENCES `centrum_doradztwa`.`wizyty` (`id_wizyty`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `FK2_rez`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `FK3_rez`
    FOREIGN KEY (`cena_r`)
    REFERENCES `centrum_doradztwa`.`ceny` (`kwota`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 3
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`testy`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`testy` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`testy` (
  `id_testu` INT(11) NOT NULL AUTO_INCREMENT,
  `id_uzytkownika` INT(11) NOT NULL,
  `data_t` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_testu`),
  INDEX `FK1_idx` (`id_uzytkownika` ASC),
  CONSTRAINT `FK1_t`
    FOREIGN KEY (`id_uzytkownika`)
    REFERENCES `centrum_doradztwa`.`uzytkownicy` (`id_uzytkownika`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
AUTO_INCREMENT = 42
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `centrum_doradztwa`.`wyniki`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `centrum_doradztwa`.`wyniki` ;

CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`wyniki` (
  `id_testu` INT(11) NOT NULL,
  `kolor` ENUM('BRAK', 'BIALY', 'CZERWONY', 'ZOLTY', 'NIEBIESKI') NOT NULL,
  `suma_a` TINYINT(4) NULL DEFAULT NULL,
  `suma_b` TINYINT(4) NULL DEFAULT NULL,
  `suma_c` TINYINT(4) NULL DEFAULT NULL,
  `suma_d` TINYINT(4) NULL DEFAULT NULL,
  PRIMARY KEY (`id_testu`),
  CONSTRAINT `FK1_wiz`
    FOREIGN KEY (`id_testu`)
    REFERENCES `centrum_doradztwa`.`testy` (`id_testu`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8;

USE `centrum_doradztwa` ;

-- -----------------------------------------------------
-- Placeholder table for view `centrum_doradztwa`.`faktury`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `centrum_doradztwa`.`faktury` (`id_uzytkownika` INT, `imie` INT, `nazwisko` INT, `telefon` INT, `adres` INT, `cena` INT, `opis` INT);

-- -----------------------------------------------------
-- View `centrum_doradztwa`.`faktury`
-- -----------------------------------------------------
DROP VIEW IF EXISTS `centrum_doradztwa`.`faktury` ;
DROP TABLE IF EXISTS `centrum_doradztwa`.`faktury`;
USE `centrum_doradztwa`;
CREATE OR REPLACE ALGORITHM = UNDEFINED 
DEFINER =`root`@`localhost` 
SQL SECURITY DEFINER 

VIEW `centrum_doradztwa`.`faktury` AS 
  SELECT 
  `centrum_doradztwa`.`uzytkownicy`.`id_uzytkownika` AS `id_uzytkownika`,
  `centrum_doradztwa`.`uzytkownicy`.`imie` AS `imie`,
  `centrum_doradztwa`.`uzytkownicy`.`nazwisko` AS `nazwisko`,
  `centrum_doradztwa`.`uzytkownicy`.`telefon` AS `telefon`,
  `centrum_doradztwa`.`uzytkownicy`.`adres` AS `adres`,
  `centrum_doradztwa`.`rezerwacje`.`cena_r` AS `cena`,
  `centrum_doradztwa`.`ceny`.`opis` AS `opis` 
    FROM 
      (((`centrum_doradztwa`.`uzytkownicy` 
         JOIN `centrum_doradztwa`.`oplaty` 
          ON(((`centrum_doradztwa`.`uzytkownicy`.`id_uzytkownika` = `centrum_doradztwa`.`oplaty`.`id_uzytkownika`) 
            AND ((`centrum_doradztwa`.`oplaty`.`czy_op_rezerwacja` = 'TAK') 
            OR (`centrum_doradztwa`.`oplaty`.`czy_op_rezerwacja` = 'BRAK'))))) 
        JOIN `centrum_doradztwa`.`rezerwacje` 
          ON((`centrum_doradztwa`.`oplaty`.`id_uzytkownika` = `centrum_doradztwa`.`rezerwacje`.`id_uzytkownika`))) 
       JOIN `centrum_doradztwa`.`ceny` 
          ON((`centrum_doradztwa`.`rezerwacje`.`cena_r` = `centrum_doradztwa`.`ceny`.`kwota`)));

USE `centrum_doradztwa`;

DELIMITER $$

USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`uzytkownicy_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`uzytkownicy_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`uzytkownicy`
FOR EACH ROW
BEGIN
DECLARE id_u INT;
DECLARE dane VARCHAR(45);

    IF
    (new.wiek < 5 ) OR (new.wiek > 100 ) then
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIEPRAWIDŁOWY WIEK!';
	END IF;
   
   IF
    (new.wiek > 17 ) then
	set new.email_u_d = 'NIE WYMAGANY';
    set new.dane_d = 'NIE WYMAGANE';
	END IF;	

	IF
    (new.wiek < 18) AND (new.email_u_d = 'BRAK' ) then
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIE PODANO OPIEKUNA!';
	END IF;
    
    IF new.email_u_d not in (
    select uzytkownicy.email_u
    from uzytkownicy
    where (new.email_u_d = uzytkownicy.email_u)
    ) AND
    (new.wiek < 18) then
  	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIE ISTNIEJE TAKI OPIEKUN!';
	END IF;
    
    SELECT id_uzytkownika INTO id_u FROM uzytkownicy WHERE new.email_u_d = email_u;
    
	IF id_u  NOT IN (
    select dorosli.id_uzytkownika
    from dorosli
    where (id_u = dorosli.id_uzytkownika) AND (dorosli.czy_opiekun = 'TAK')
    ) 
    AND (new.wiek < 18) 
    then
  	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! UZYTKOWNIK NIE WYRAZIL ZGODY NA BYCIE OPIEKUNEM!';
	
    END IF;
    
    SELECT CONCAT(imie,' ',nazwisko) INTO dane FROM uzytkownicy WHERE id_uzytkownika = id_u;
    
    IF
    (new.wiek < 18 ) then
	set new.dane_d = dane;
    END IF;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`uzytkownicy_AFTER_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`uzytkownicy_AFTER_INSERT`
AFTER INSERT ON `centrum_doradztwa`.`uzytkownicy`
FOR EACH ROW
BEGIN

declare id, id2 INT;	

IF (New.wiek > 17) 
	then 
	insert into dorosli (id_uzytkownika) value (new.id_uzytkownika);
ELSE
	SELECT id_uzytkownika INTO id FROM uzytkownicy WHERE new.email_u_d = email_u;
	SELECT id_doroslego INTO id2 FROM dorosli WHERE dorosli.id_uzytkownika = id;
	insert into nieletni(id_uzytkownika, id_uzytkownika_d) values(new.id_uzytkownika, id2);
end if;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`uzytkownicy_BEFORE_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`uzytkownicy_BEFORE_UPDATE`
BEFORE UPDATE ON `centrum_doradztwa`.`uzytkownicy`
FOR EACH ROW
BEGIN
  DECLARE id_u INT;
  DECLARE dane VARCHAR(45);
  
    IF
    (new.wiek < 5 ) OR (new.wiek > 100 ) then
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIEPRAWIDŁOWY WIEK!';
	END IF;
   
   IF
    (new.wiek > 17 ) then
	set new.email_u_d = 'NIE WYMAGANY';
    set new.dane_d = 'NIE WYMAGANE';
	END IF;	

	IF
    (new.wiek < 18) AND (new.email_u_d = 'BRAK' ) then
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIE PODANO OPIEKUNA!';
	END IF;
    
    IF new.email_u_d not in (
    select uzytkownicy.email_u
    from uzytkownicy
    where (new.email_u_d = uzytkownicy.email_u)
    ) AND
    (new.wiek < 18) then
  	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! NIE ISTNIEJE TAKI OPIEKUN!';
	END IF;
    
    SELECT id_uzytkownika INTO id_u FROM uzytkownicy WHERE new.email_u_d = email_u;
    
	IF id_u  NOT IN (
    select dorosli.id_uzytkownika
    from dorosli
    where (id_u = dorosli.id_uzytkownika) AND (dorosli.czy_opiekun = 'TAK')
    ) 
    AND (new.wiek < 18) 
    then
  	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ UZYTKOWNIKA! UZYTKOWNIK NIE WYRAZIL ZGODY NA BYCIE OPIEKUNEM!';
	END IF;
        
    SELECT CONCAT(imie,' ',nazwisko) INTO dane FROM uzytkownicy WHERE id_uzytkownika = id_u;
    
    IF
    (new.wiek < 18 ) then
	set new.dane_d = dane;
    END IF;
    
    
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`uzytkownicy_AFTER_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`uzytkownicy_AFTER_UPDATE`
AFTER UPDATE ON `centrum_doradztwa`.`uzytkownicy`
FOR EACH ROW
BEGIN
DECLARE id, id2 varchar(45);
	
IF (New.wiek > 17) 
THEN 
	IF NEW.id_uzytkownika IN (
            SELECT nieletni.id_uzytkownika
            FROM  nieletni
            WHERE (NEW.id_uzytkownika = nieletni.id_uzytkownika)
        ) THEN 
	insert into dorosli (id_uzytkownika) value(new.id_uzytkownika);
	delete from nieletni where nieletni.id_uzytkownika = new.id_uzytkownika;
	END if;
ELSE
	IF NEW.id_uzytkownika NOT IN (
            SELECT nieletni.id_uzytkownika
            FROM  nieletni
            WHERE (NEW.id_uzytkownika = nieletni.id_uzytkownika)
        ) THEN 
       SELECT id_uzytkownika INTO id FROM uzytkownicy WHERE new.email_u_d = email_u;
		SELECT id_doroslego INTO id2 FROM dorosli WHERE dorosli.id_uzytkownika = id;
		insert into nieletni(id_uzytkownika, id_uzytkownika_d) values(new.id_uzytkownika, id2);
		delete from dorosli where id_uzytkownika = new.id_uzytkownika;
	END if;
END if;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`historia_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`historia_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`historia`
FOR EACH ROW
BEGIN
DECLARE id INT(11);
declare dane VARCHAR(65);

SELECT id_uzytkownika INTO id FROM centrum_doradztwa.rezerwacje WHERE centrum_doradztwa.rezerwacje.id_wizyty = NEW.id_wizyty;

SET NEW.id_uzytkownika = id;

SELECT CONCAT(imie,' ',nazwisko) INTO dane FROM doradcy WHERE id_doradcy = NEW.id_doradcy;
SET NEW.dane_doradcy = dane;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`historia_AFTER_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`historia_AFTER_INSERT`
AFTER INSERT ON `centrum_doradztwa`.`historia`
FOR EACH ROW
BEGIN
DECLARE d4 ENUM('NIE','TAK');

SELECT czy_op_test INTO d4 FROM oplaty WHERE oplaty.id_uzytkownika = new.id_uzytkownika;

If (d4 = 'TAK') then
	update oplaty set czy_op_rezerwacja = 'BRAK' where oplaty.id_uzytkownika = new.id_uzytkownika;
    END IF;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`wizyty_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`wizyty_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`wizyty`
FOR EACH ROW
BEGIN
declare data123 VARCHAR(45);
declare dane VARCHAR(65);
IF
    (new.dzien_w < 1 ) OR (new.dzien_w > 31 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;

IF
    (new.miesiac_w < 1 ) OR (new.miesiac_w > 12 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;

IF
    (new.rok_w < 2017 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;

SET NEW.data_w = STR_TO_DATE(CONCAT(CAST(new.rok_w as CHAR(45)), '/', CAST(new.miesiac_w as CHAR(45)), '/', CAST(new.dzien_w as CHAR(45)),' ', CAST(new.godzina_w as CHAR(45))),'%Y/%m/%d %T');
 IF ((DATEDIFf(NEW.data_w, CURDATE()) <= -1)) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! TA DATA JUŻ BYŁA!';
END IF;

SELECT CONCAT(imie,' ',nazwisko) INTO dane FROM doradcy WHERE id_doradcy = NEW.id_doradcy;
SET NEW.dane_doradcy = dane;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`wizyty_BEFORE_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`wizyty_BEFORE_UPDATE`
BEFORE UPDATE ON `centrum_doradztwa`.`wizyty`
FOR EACH ROW
BEGIN
IF
    (new.dzien_w < 1 ) OR (new.dzien_w > 31 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;

IF
    (new.miesiac_w < 1 ) OR (new.miesiac_w > 12 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;

IF
    (new.rok_w < 2017 ) then
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! ZLA DATA';
END if;


SET NEW.data_w = STR_TO_DATE(CONCAT(CAST(new.rok_w as CHAR(45)), '/', CAST(new.miesiac_w as CHAR(45)), '/', CAST(new.dzien_w as CHAR(45)),' ', CAST(new.godzina_w as CHAR(45))),'%Y/%m/%d %T');
 IF (DATE(NEW.data_w) < DATE(Now())) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! TA DATA JUŻ BYŁA!';
   END IF;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`rezerwacje_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`rezerwacje_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`rezerwacje`
FOR EACH ROW
BEGIN
DECLARE d DATETIME;
DECLARE D2 DATETIME;
SELECT data_w INTO D2 FROM centrum_doradztwa.wizyty WHERE wizyty.id_wizyty = new.id_wizyty; 

if new.id_uzytkownika NOT IN (
select testy.id_uzytkownika
from testy
where testy.id_uzytkownika = new.id_uzytkownika) then 
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: NIE WYKONANO TESTU!';
END IF;

if new.id_uzytkownika IN (
select rezerwacje.id_uzytkownika
from rezerwacje
where rezerwacje.id_uzytkownika = new.id_uzytkownika) then 
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: TEN UŻYTKOWNIK MA JUZ REZERWACJĘ!';
END IF;

if new.id_wizyty IN (
select rezerwacje.id_wizyty
from rezerwacje
where rezerwacje.id_wizyty = new.id_wizyty) then 
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: TA WIZYTA JEST JUŻ ZAREZERWOWANA!';
END IF;


IF (DATEDIFF(NEW.data_r, CURDATE()) <= -1) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! TA DATA JUŻ BYŁA!';
END IF;

IF ((DATEDIFF(D2, CURDATE()) <= 6) AND (DATEDIFF(D2, CURDATE()) > 0)) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! WYBRANA WIZYTA JEST ZA WCZEŚNIE!';
END IF;

IF (NEW.id_uzytkownika) IN (
	SELECT oplaty.id_uzytkownika
	FROM oplaty
	WHERE oplaty.id_uzytkownika = NEW.id_uzytkownika) 
    THEN
		SET NEW.cena_r = '200';
ELSE 
	SET NEW.cena_r = '220';
END IF;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`rezerwacje_AFTER_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`rezerwacje_AFTER_INSERT`
AFTER INSERT ON `centrum_doradztwa`.`rezerwacje`
FOR EACH ROW
BEGIN
IF New.id_uzytkownika NOT IN (
SELECT oplaty.id_uzytkownika
FROM oplaty
WHERE New.id_uzytkownika = oplaty.id_uzytkownika) THEN 
insert into oplaty(id_uzytkownika) values(New.id_uzytkownika);
END IF;

IF New.id_uzytkownika IN (
SELECT oplaty.id_uzytkownika
FROM oplaty
WHERE New.id_uzytkownika = oplaty.id_uzytkownika) THEN 
UPDATE oplaty set czy_op_rezerwacja = "NIE" where oplaty.id_uzytkownika = NEW.id_uzytkownika;
END IF;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`rezerwacje_BEFORE_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`rezerwacje_BEFORE_UPDATE`
BEFORE UPDATE ON `centrum_doradztwa`.`rezerwacje`
FOR EACH ROW
BEGIN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'REZERWACJI SIE NIE EDYTUJE!';
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`rezerwacje_BEFORE_DELETE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`rezerwacje_BEFORE_DELETE`
BEFORE DELETE ON `centrum_doradztwa`.`rezerwacje`
FOR EACH ROW
BEGIN

DECLARE d3 ENUM('NIE','TAK');

SELECT czy_op_test INTO d3 FROM oplaty WHERE oplaty.id_uzytkownika = old.id_uzytkownika;

If (d3 = 'TAK') then
	update oplaty set czy_op_rezerwacja = 'BRAK' where oplaty.id_uzytkownika = old.id_uzytkownika;
else
	delete from oplaty where oplaty.id_uzytkownika = old.id_uzytkownika;
END if;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`testy_AFTER_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`testy_AFTER_INSERT`
AFTER INSERT ON `centrum_doradztwa`.`testy`
FOR EACH ROW
BEGIN
IF NEW.id_testu not in (
            select wyniki.id_testu
            From  wyniki
            where (NEW.id_testu = wyniki.id_testu)
        ) THEN 
	insert into wyniki(id_testu) values(new.id_testu);
END if;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`testy_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`testy_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`testy`
FOR EACH ROW
BEGIN

IF NEW.id_uzytkownika in (
            select testy.id_uzytkownika
            From  testy
            where (NEW.id_uzytkownika =  testy.id_uzytkownika)
        ) THEN 
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: TEN UŻYTKOWNIK MA JUŻ TEST!';
END if;

IF (DATEDIFf(NEW.data_t, CURDATE()) <= -1) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! TA DATA JUŻ BYŁA!';
END IF;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`testy_BEFORE_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`testy_BEFORE_UPDATE`
BEFORE UPDATE ON `centrum_doradztwa`.`testy`
FOR EACH ROW
BEGIN
IF NEW.id_uzytkownika in (
            select testy.id_uzytkownika
            From  testy
            where (NEW.id_uzytkownika =  testy.id_uzytkownika)
        ) THEN 
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: TEN UŻYTKOWNIK MA JUŻ TEST!';
END if;

IF (DATE(NEW.data_t) < CURDATE()) THEN
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ! TA DATA JUŻ BYŁA!';
END IF;

END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`wyniki_BEFORE_INSERT` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`wyniki_BEFORE_INSERT`
BEFORE INSERT ON `centrum_doradztwa`.`wyniki`
FOR EACH ROW
BEGIN
IF NEW.id_testu in (
            select wyniki.id_testu
            From  wyniki
            where (NEW.id_testu =  wyniki.id_testu)
        ) THEN 
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA DODAĆ: TEN TEST MA JUŻ WYNIK!';
END if;
END$$


USE `centrum_doradztwa`$$
DROP TRIGGER IF EXISTS `centrum_doradztwa`.`wyniki_BEFORE_UPDATE` $$
USE `centrum_doradztwa`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `centrum_doradztwa`.`wyniki_BEFORE_UPDATE`
BEFORE UPDATE ON `centrum_doradztwa`.`wyniki`
FOR EACH ROW
BEGIN
IF NEW.id_testu in (
            select wyniki.id_testu
            From  wyniki
            where (NEW.id_testu =  wyniki.id_testu)
        ) AND
        (OLD.kolor != 'BRAK')
        THEN 
	SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'NIE MOŻNA ZMIENIĆ: TEN TEST MA JUŻ WYNIK!';
END IF;
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
