set GLOBAL event_scheduler = ON;

CREATE EVENT IF NOT EXISTS usun_nieletnich ON SCHEDULE EVERY 1 MINUTE ON COMPLETION PRESERVE DO 
DELETE FROM centrum_doradztwa.uzytkownicy 
WHERE (centrum_doradztwa.uzytkownicy.email_u_d !='NIE WYMAGANY')
AND (centrum_doradztwa.uzytkownicy.id_uzytkownika NOT IN (SELECT centrum_doradztwa.nieletni.id_uzytkownika FROM centrum_doradztwa.nieletni));

CREATE EVENT IF NOT EXISTS ustaw_op_test ON SCHEDULE EVERY 1 MINUTE ON COMPLETION PRESERVE DO 
UPDATE centrum_doradztwa.oplaty 
SET centrum_doradztwa.oplaty.czy_op_test = 'TAK' 
WHERE (centrum_doradztwa.oplaty.czy_op_test = 'NIE') AND (centrum_doradztwa.oplaty.czy_op_rezerwacja = 'TAK');


delimiter |
CREATE EVENT IF NOT EXISTS usun_uzytkownika_wg_rezerw ON SCHEDULE EVERY 1 DAY STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 DAY + INTERVAL 5 MINUTE) ON COMPLETION PRESERVE DO 
BEGIN
DELETE FROM centrum_doradztwa.uzytkownicy
WHERE (centrum_doradztwa.uzytkownicy.id_uzytkownika IN (
	SELECT oplaty.id_uzytkownika 
    FROM centrum_doradztwa.oplaty 
    WHERE (centrum_doradztwa.oplaty.id_uzytkownika = centrum_doradztwa.uzytkownicy.id_uzytkownika) AND (centrum_doradztwa.oplaty.czy_op_test = 'NIE'))
    )
AND (centrum_doradztwa.uzytkownicy.id_uzytkownika IN (
	SELECT rezerwacje.id_uzytkownika 
    FROM centrum_doradztwa.rezerwacje 
    WHERE (centrum_doradztwa.rezerwacje.id_uzytkownika = centrum_doradztwa.uzytkownicy.id_uzytkownika) AND ((timestampdiff(DAY, centrum_doradztwa.rezerwacje.data_r, curdate())) >= 5) 
    )
AND ((DAYNAME(curdate()) != 'Monday'))
);

DELETE FROM centrum_doradztwa.uzytkownicy
WHERE (centrum_doradztwa.uzytkownicy.id_uzytkownika IN (
	SELECT oplaty.id_uzytkownika 
    FROM centrum_doradztwa.oplaty 
    WHERE (centrum_doradztwa.oplaty.id_uzytkownika = centrum_doradztwa.uzytkownicy.id_uzytkownika) AND (centrum_doradztwa.oplaty.czy_op_rezerwacja = 'NIE')
    )
)
AND (centrum_doradztwa.uzytkownicy.id_uzytkownika IN (
	SELECT rezerwacje.id_uzytkownika 
    FROM centrum_doradztwa.rezerwacje 
    WHERE (centrum_doradztwa.rezerwacje.id_uzytkownika = centrum_doradztwa.uzytkownicy.id_uzytkownika) AND ((timestampdiff(DAY, centrum_doradztwa.rezerwacje.data_r, Now())) >= 5) 
    )
AND ((DAYNAME(curdate()) != 'Monday'))
);

END |
delimiter ;

delimiter |
CREATE EVENT IF NOT EXISTS przenies_do_historii 
ON SCHEDULE EVERY 1 DAY STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 DAY + INTERVAL 10 MINUTE) 
ON COMPLETION PRESERVE DO 
BEGIN 
INSERT INTO historia (id_wizyty, id_doradcy, data) 
SELECT id_wizyty, id_doradcy, data_w
FROM centrum_doradztwa.wizyty
WHERE (centrum_doradztwa.wizyty.id_wizyty IN (
	SELECT rezerwacje.id_wizyty 
    FROM centrum_doradztwa.rezerwacje 
    WHERE (centrum_doradztwa.wizyty.id_wizyty = centrum_doradztwa.rezerwacje.id_wizyty) 
		AND (DATE(centrum_doradztwa.wizyty.data_w) < CURDATE())
    )
); 

UPDATE centrum_doradztwa.oplaty 
SET centrum_doradztwa.oplaty.czy_op_rezerwacja = 'BRAK' 
WHERE centrum_doradztwa.oplaty.id_uzytkownika IN (
	SELECT rezerwacje.id_uzytkownika 
    FROM centrum_doradztwa.rezerwacje 
    WHERE (centrum_doradztwa.oplaty.id_uzytkownika = rezerwacje.id_uzytkownika) 
		AND (rezerwacje.id_wizyty IN (SELECT historia.id_wizyty FROM centrum_doradztwa.historia)
    )
);
  
DELETE FROM centrum_doradztwa.rezerwacje
WHERE (centrum_doradztwa.rezerwacje.id_wizyty IN (
	SELECT historia.id_wizyty
    FROM centrum_doradztwa.historia
    WHERE (centrum_doradztwa.rezerwacje.id_wizyty = centrum_doradztwa.historia.id_wizyty) 
    )
);

END |
delimiter ;

CREATE EVENT IF NOT EXISTS wyczysc_wizyty ON SCHEDULE EVERY 1 DAY STARTS (TIMESTAMP(CURRENT_DATE) + INTERVAL 1 DAY + INTERVAL 15 MINUTE) ON COMPLETION PRESERVE DO 
DELETE FROM centrum_doradztwa.wizyty WHERE (DATE(centrum_doradztwa.wizyty.data_w) < CURDATE()); 

